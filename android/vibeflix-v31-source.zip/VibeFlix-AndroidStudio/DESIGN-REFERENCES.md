# Vibeflix design research

Research reviewed 2026-11-16. This is a research guide, not an official Netflix specification.

## Source hierarchy

1. Netflix's official article on Hawkins: https://netflixtechblog.com/hawkins-diving-into-the-reasoning-behind-our-design-system-964a7357547 — discusses the Studio/internal system, not a complete consumer mobile specification.
2. Interview with Netflix system designer Amber Feinerman: https://thedesignsystem.guide/interview-amber-feinerman — describes separate Professional and Consumer sides of Hawkins and shared tokens/assets for Android, iOS, TV, and Web.
3. Screenshots of Netflix Android Home: https://mobbin.com/explore/flows/23d75fba-e421-43b2-bb6c-2a36eab6bedb — observations from a specific captured version, not a promise of current behavior or all regions.
4. A Netflix iOS Fast Laughs pull-to-refresh screen: https://mobbin.com/explore/screens/b1893615-b116-4d7b-b9bf-652e40171cb3 — specific older feature, not Android Home and not a video of the interaction.
5. An independent Android recreation: https://github.com/premkumar0184/Netflix-Android — self-described reverse engineering. Claims and tokens are not independently verified or official. Repository API did not identify an open-source license when checked. Do not copy code/assets without checking permissions.
6. Independent inferred design description: https://oh-my-design.kr/design-systems/netflix — useful inspiration, not an official token specification; includes desktop and marketing patterns that must not be blindly applied to Android.

## Application principles for Vibeflix
- Inspect the specific Android screen and interaction before making Netflix-fidelity claims; record reference date, platform and evidence.
- Dark canvas and high-contrast text; restrained color; content artwork remains the focus.
- Preserve platform-appropriate touch targets, accessibility labels, reduced-motion behavior and clear loading/error/empty states.
- Keep native navigation and actual Play4u-backed categories and titles; never invent feeds or unsupported features.
- Keep existing skeleton loading preference; respect Vibeflix branding rather than copying logos or proprietary assets.
- Netflix Sans is proprietary; bundled Barlow is an openly licensed substitute, not the real font.
- Netflix Android Home's exact current pull-to-refresh animation remains unverified. The current Vibeflix treatment is an original interpretation, not Hawkins documentation or a Netflix reproduction.
