package org.example.play4u;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Local-first sync for latest-per-title History, playback resume, and Continue Watching state. */
public final class SupabasePlaybackSync {
    private static final String PREFS = "vibeflix_supabase_library_sync";
    private static final String HISTORY_TOMBSTONES = "watch_history_tombstones_v1";
    private static final String PROGRESS_ROWS = "watch_progress_state_v1";
    private static final String HIDDEN_ROWS = "continue_hidden_state_v1";
    private static final String HISTORY_CLEAR_AT = "history_cleared_at_ms_v1";
    private static final String[] HISTORY_PREFS = {"watch_history", "watch_history_movy"};
    private static final String[] LIST_PREFS = {"my_list", "my_list_movy"};

    private final Context app;
    private final SupabaseRestClient rest;

    public SupabasePlaybackSync(Context context) {
        this(context, new SupabaseRestClient());
    }

    SupabasePlaybackSync(Context context, SupabaseRestClient rest) {
        app = context.getApplicationContext();
        this.rest = rest;
    }

    /** Next play timestamp is monotonic against local tombstones and account-wide clears. */
    public static long nextHistoryTimestamp(Context context, MainActivity.Item item) {
        if (context == null || item == null) return System.currentTimeMillis();
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long previous = Math.max(item.time, prefs.getLong(HISTORY_CLEAR_AT, 0L));
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (identity != null) {
            JSONObject tombstones = readObject(prefs, HISTORY_TOMBSTONES);
            JSONObject row = tombstones.optJSONObject(identity.id);
            if (row != null) previous = Math.max(previous, row.optLong("time", 0L));
            JSONObject progressRows = readObject(prefs, PROGRESS_ROWS);
            Iterator<String> progressKeys = progressRows.keys();
            while (progressKeys.hasNext()) {
                JSONObject progress = progressRows.optJSONObject(progressKeys.next());
                if (progress != null && identity.id.equals(progress.optString("title_id", ""))) {
                    previous = Math.max(previous, progress.optLong("time", 0L));
                }
            }
            JSONObject hidden = readObject(prefs, HIDDEN_ROWS).optJSONObject(identity.id);
            if (hidden != null) previous = Math.max(previous, hidden.optLong("time", 0L));
            for (String name : HISTORY_PREFS) {
                try {
                    JSONArray local = new JSONArray(context.getApplicationContext()
                            .getSharedPreferences(name, Context.MODE_PRIVATE).getString("items", "[]"));
                    for (int i = 0; i < local.length(); i++) {
                        MainActivity.Item existing = decodeItem(local.optJSONObject(i));
                        SupabaseLibrarySync.TitleIdentity oldId = SupabaseLibrarySync.identityFor(existing);
                        if (oldId != null && identity.id.equals(oldId.id)) previous = Math.max(previous, existing.time);
                    }
                } catch (Exception ignored) { }
            }
        }
        return nextAfter(previous);
    }

    public static void clearHistoryTombstone(Context context, MainActivity.Item item) {
        if (context == null || item == null) return;
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (identity == null) return;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (SupabaseLibrarySync.localLock()) {
            JSONObject rows = readObject(prefs, HISTORY_TOMBSTONES);
            rows.remove(identity.id);
            prefs.edit().putString(HISTORY_TOMBSTONES, rows.toString()).commit();
        }
    }

    public static void recordHistoryRemoval(Context context, MainActivity.Item item) {
        if (context == null || item == null) return;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (identity == null) return;
        synchronized (SupabaseLibrarySync.localLock()) {
            JSONObject rows = readObject(prefs, HISTORY_TOMBSTONES);
            long time = nextHistoryTimestamp(context, item);
            try {
                rows.put(identity.id, encodeHistory(new HistoryState(identity.id, false, time, item)));
                prefs.edit().putString(HISTORY_TOMBSTONES, rows.toString()).commit();
            } catch (JSONException ignored) {
                // Do not destroy local History if tombstone serialization fails.
            }
        }
    }

    /** Records a global watermark so a stale offline device cannot restore cleared rows. */
    public static void recordHistoryClear(Context context, List<MainActivity.Item> items) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (SupabaseLibrarySync.localLock()) {
            JSONObject tombstones = readObject(prefs, HISTORY_TOMBSTONES);
            long previous = prefs.getLong(HISTORY_CLEAR_AT, 0L);
            Iterator<String> historyKeys = tombstones.keys();
            while (historyKeys.hasNext()) {
                JSONObject old = tombstones.optJSONObject(historyKeys.next());
                if (old != null) previous = Math.max(previous, old.optLong("time", 0L));
            }
            for (String stateKey : new String[]{PROGRESS_ROWS, HIDDEN_ROWS}) {
                JSONObject states = readObject(prefs, stateKey);
                Iterator<String> stateKeys = states.keys();
                while (stateKeys.hasNext()) {
                    JSONObject old = states.optJSONObject(stateKeys.next());
                    if (old != null) previous = Math.max(previous, old.optLong("time", 0L));
                }
            }
            if (items != null) for (MainActivity.Item item : items) {
                if (item != null) previous = Math.max(previous, item.time);
            }
            long clearAt = nextAfter(previous);
            if (items != null) for (MainActivity.Item item : items) {
                SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
                if (identity == null) continue;
                try {
                    tombstones.put(identity.id, encodeHistory(new HistoryState(identity.id, false, clearAt, item)));
                } catch (JSONException ignored) {
                    // The global watermark still protects remote rows.
                }
            }
            prefs.edit().putLong(HISTORY_CLEAR_AT, clearAt)
                    .putString(HISTORY_TOMBSTONES, tombstones.toString()).commit();
        }
    }

    /** Store hide/unhide locally with a per-title monotonic timestamp; uploads remain opt-in. */
    public static void recordContinueHidden(Context context, MainActivity.Item item, boolean hidden) {
        if (context == null || item == null) return;
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (identity == null) return;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (SupabaseLibrarySync.localLock()) {
            JSONObject rows = readObject(prefs, HIDDEN_ROWS);
            JSONObject old = rows.optJSONObject(identity.id);
            JSONObject historyTombstone = readObject(prefs, HISTORY_TOMBSTONES).optJSONObject(identity.id);
            long previous = Math.max(Math.max(item.time, prefs.getLong(HISTORY_CLEAR_AT, 0L)),
                    old == null ? 0L : old.optLong("time", 0L));
            if (historyTombstone != null) previous = Math.max(previous, historyTombstone.optLong("time", 0L));
            JSONObject progressRows = readObject(prefs, PROGRESS_ROWS);
            Iterator<String> progressKeys = progressRows.keys();
            while (progressKeys.hasNext()) {
                JSONObject progress = progressRows.optJSONObject(progressKeys.next());
                if (progress != null && identity.id.equals(progress.optString("title_id", ""))) {
                    previous = Math.max(previous, progress.optLong("time", 0L));
                }
            }
            try {
                rows.put(identity.id, encodeHidden(new HiddenState(identity.id, hidden, nextAfter(previous), item)));
                prefs.edit().putString(HIDDEN_ROWS, rows.toString()).commit();
            } catch (JSONException ignored) {
                // Local shelf visibility remains available even if sync metadata cannot be written.
            }
        }
    }

    /** Persist each player checkpoint with no playback URL in its sync representation. */
    public static void recordLocalProgress(Context context, String titleUrl, String playbackUrl,
                                           String title, long positionMs, long durationMs, boolean completed) {
        if (context == null || titleUrl == null || playbackUrl == null) return;
        SharedPreferences sync = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (SupabaseLibrarySync.localLock()) {
            MainActivity.Item item = findItem(context, titleUrl);
            if (item == null) item = new MainActivity.Item(title == null ? "" : title, titleUrl, "", "");
            SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
            String episode = episodeKey(item, playbackUrl);
            if (identity == null || episode == null) return;
            JSONObject rows = readObject(sync, PROGRESS_ROWS);
            String key = progressKey(identity.id, episode);
            long previous = item.time;
            Iterator<String> existingKeys = rows.keys();
            while (existingKeys.hasNext()) {
                JSONObject existing = rows.optJSONObject(existingKeys.next());
                if (existing != null && identity.id.equals(existing.optString("title_id", ""))) {
                    previous = Math.max(previous, existing.optLong("time", 0L));
                }
            }
            JSONObject historyTombstone = readObject(sync, HISTORY_TOMBSTONES).optJSONObject(identity.id);
            previous = Math.max(previous, sync.getLong(HISTORY_CLEAR_AT, 0L));
            if (historyTombstone != null) previous = Math.max(previous, historyTombstone.optLong("time", 0L));
            long safeDuration = Math.max(0L, durationMs);
            long safePosition = Math.max(0L, positionMs);
            if (safeDuration > 0L) safePosition = Math.min(safePosition, safeDuration);
            try {
                rows.put(key, encodeProgress(new ProgressState(identity.id, episode, safePosition,
                        safeDuration, completed, true, nextAfter(previous), item)));
                sync.edit().putString(PROGRESS_ROWS, rows.toString()).commit();
            } catch (JSONException ignored) {
                // Local playback position is already saved by NativePlayerActivity.
            }
        }
    }

    /** Turn stored episode checkpoints into removal tombstones when a title leaves History. */
    public static void recordTitleProgressRemoval(Context context, MainActivity.Item item) {
        if (context == null || item == null) return;
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (identity == null) return;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (SupabaseLibrarySync.localLock()) {
            JSONObject rows = readObject(prefs, PROGRESS_ROWS);
            JSONObject historyTombstone = readObject(prefs, HISTORY_TOMBSTONES).optJSONObject(identity.id);
            long historyRemovedAt = Math.max(prefs.getLong(HISTORY_CLEAR_AT, 0L),
                    historyTombstone == null ? 0L : historyTombstone.optLong("time", 0L));
            Iterator<String> keys = rows.keys();
            boolean changed = false;
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject row = rows.optJSONObject(key);
                if (row == null || !identity.id.equals(row.optString("title_id", ""))) continue;
                long time = nextAfter(Math.max(Math.max(row.optLong("time", item.time), item.time), historyRemovedAt));
                try {
                    row.put("present", false);
                    row.put("position_ms", 0L);
                    row.put("completed", false);
                    row.put("time", time);
                    changed = true;
                } catch (JSONException ignored) {
                    // Preserve any other local checkpoints.
                }
            }
            if (changed) prefs.edit().putString(PROGRESS_ROWS, rows.toString()).commit();
        }
    }

    public SyncResult sync(SupabaseSessionStore.Session session) throws IOException {
        if (session == null || isEmpty(session.userId) || isEmpty(session.accessToken)) {
            throw new IOException("Sign in before syncing History and playback.");
        }
        if (!SupabaseLibrarySync.isEnabledFor(app, session.userId)) {
            throw new IOException("Enable library sync for this account first.");
        }

        // Fetch everything before touching local preferences; a network failure stays non-destructive.
        JSONArray remoteHistoryRows = rest.fetchWatchHistory(session.userId, session.accessToken);
        JSONArray remoteProgressRows = rest.fetchWatchProgress(session.userId, session.accessToken);
        JSONArray remoteHiddenRows = rest.fetchContinueHidden(session.userId, session.accessToken);
        JSONArray remoteLibraryRows = rest.fetchLibraryState(session.userId, session.accessToken);
        long remoteClear = parseLibraryClear(remoteLibraryRows);
        long serverClear = syncClearWatermark(session, remoteClear);

        Map<String, HistoryState> history;
        Map<String, ProgressState> progress;
        Map<String, HiddenState> hidden;
        Map<String, HistoryState> submittedHistory;
        Map<String, ProgressState> submittedProgress;
        Map<String, HiddenState> submittedHidden;
        ArrayList<JSONObject> titles;
        JSONArray historyWrites;
        JSONArray progressWrites;
        JSONArray hiddenWrites;
        long clearAt;

        // Keep each local snapshot/merge/write atomic with UI and player mutations.
        synchronized (SupabaseLibrarySync.localLock()) {
            SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            clearAt = Math.max(serverClear, prefs.getLong(HISTORY_CLEAR_AT, 0L));
            history = mergeHistory(readLocalHistory(), parseHistory(remoteHistoryRows));
            progress = mergeProgress(readLocalProgress(history), parseProgress(remoteProgressRows));
            hidden = mergeHidden(readLocalHidden(history), parseHidden(remoteHiddenRows));
            applyHistoryClear(history, progress, hidden, clearAt);
            applyHistoryRemovalsToProgress(history, progress);
            writeLocalHistory(history, clearAt);
            writeLocalProgress(progress);
            writeLocalHidden(hidden, history);

            submittedHistory = new HashMap<>(history);
            submittedProgress = new HashMap<>(progress);
            submittedHidden = new HashMap<>(hidden);
            titles = collectTitleRows(session.userId, history, progress, hidden);
            historyWrites = historyPayload(session.userId, history);
            progressWrites = progressPayload(session.userId, progress);
            hiddenWrites = hiddenPayload(session.userId, hidden);
        }

        // The watermark must be durable before tombstones are sent, so stale offline writes
        // cannot restore rows which were not present in this device's initial snapshot.
        if (clearAt > serverClear) serverClear = syncClearWatermark(session, serverClear);
        rest.upsertTitles(SupabaseLibrarySync.toJsonArray(titles), session.accessToken);
        JSONArray acceptedHistory = rest.upsertWatchHistory(historyWrites, session.accessToken);
        JSONArray acceptedProgress = rest.upsertWatchProgress(progressWrites, session.accessToken);
        JSONArray acceptedHidden = rest.upsertContinueHidden(hiddenWrites, session.accessToken);
        applyAcceptedTimes(acceptedHistory, history, null);
        applyAcceptedTimes(acceptedProgress, null, progress);
        applyAcceptedTimes(acceptedHidden, null, null, hidden);

        // Reconcile server-clamped timestamps without overwriting player/UI changes that arrived
        // while the network requests were in flight.
        synchronized (SupabaseLibrarySync.localLock()) {
            Map<String, HistoryState> currentHistory = readLocalHistory();
            Map<String, ProgressState> currentProgress = readLocalProgress(currentHistory);
            Map<String, HiddenState> currentHidden = readLocalHidden(currentHistory);
            normalizeHistoryTimes(currentHistory, submittedHistory, acceptedHistory);
            normalizeProgressTimes(currentProgress, submittedProgress, acceptedProgress);
            normalizeHiddenTimes(currentHidden, submittedHidden, acceptedHidden);
            history = mergeHistory(history, currentHistory);
            progress = mergeProgress(progress, currentProgress);
            hidden = mergeHidden(hidden, currentHidden);
            clearAt = Math.max(serverClear, app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getLong(HISTORY_CLEAR_AT, 0L));
            applyHistoryClear(history, progress, hidden, clearAt);
            applyHistoryRemovalsToProgress(history, progress);
            writeLocalHistory(history, clearAt);
            writeLocalProgress(progress);
            writeLocalHidden(hidden, history);
        }

        int activeHistory = 0;
        int resumable = 0;
        for (HistoryState state : history.values()) if (state.present) activeHistory++;
        for (ProgressState state : progress.values()) if (state.present && !state.completed && state.positionMs > 0) resumable++;
        return new SyncResult(activeHistory, resumable, hidden.size());
    }

    private long syncClearWatermark(SupabaseSessionStore.Session session, long knownServerClear) throws IOException {
        long serverClear = knownServerClear;
        SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (int attempt = 0; attempt < 3; attempt++) {
            long localClear;
            synchronized (SupabaseLibrarySync.localLock()) {
                localClear = prefs.getLong(HISTORY_CLEAR_AT, 0L);
            }
            long candidate = Math.max(localClear, serverClear);
            if (candidate <= serverClear) break;

            JSONArray payload = new JSONArray();
            JSONObject row = new JSONObject();
            try {
                row.put("user_id", session.userId);
                row.put("history_cleared_at", SupabaseLibrarySync.formatTimestamp(candidate));
                payload.put(row);
            } catch (JSONException error) {
                throw new IOException("Could not encode the History clear watermark.", error);
            }
            rest.upsertLibraryState(payload, session.accessToken);
            long confirmed = parseLibraryClear(rest.fetchLibraryState(session.userId, session.accessToken));
            if (confirmed <= 0L) throw new IOException("Supabase did not confirm the History clear watermark.");
            serverClear = Math.max(serverClear, confirmed);

            synchronized (SupabaseLibrarySync.localLock()) {
                long current = prefs.getLong(HISTORY_CLEAR_AT, 0L);
                if (current == candidate && confirmed < candidate) {
                    if (!prefs.edit().putLong(HISTORY_CLEAR_AT, confirmed).commit()) {
                        throw new IOException("Could not save the server-confirmed History clear time locally.");
                    }
                }
            }
        }
        return serverClear;
    }

    private static long parseLibraryClear(JSONArray rows) {
        JSONObject row = rows == null || rows.length() == 0 ? null : rows.optJSONObject(0);
        return row == null ? 0L : SupabaseLibrarySync.parseTimestamp(row.optString("history_cleared_at", ""));
    }

    private Map<String, HistoryState> readLocalHistory() {
        Map<String, HistoryState> result = new HashMap<>();
        for (String name : HISTORY_PREFS) {
            SharedPreferences prefs = app.getSharedPreferences(name, Context.MODE_PRIVATE);
            try {
                JSONArray rows = new JSONArray(prefs.getString("items", "[]"));
                for (int i = 0; i < rows.length(); i++) {
                    MainActivity.Item item = decodeItem(rows.optJSONObject(i));
                    SupabaseLibrarySync.TitleIdentity id = SupabaseLibrarySync.identityFor(item);
                    if (id == null) continue;
                    long time = item.time > 0L ? item.time : System.currentTimeMillis();
                    item.time = time;
                    putHistory(result, new HistoryState(id.id, true, time, item));
                }
            } catch (Exception ignored) {
                // Keep other source histories intact if one local JSON value is malformed.
            }
        }
        JSONObject tombstones = readObject(app.getSharedPreferences(PREFS, Context.MODE_PRIVATE), HISTORY_TOMBSTONES);
        Iterator<String> keys = tombstones.keys();
        while (keys.hasNext()) {
            String id = keys.next();
            JSONObject row = tombstones.optJSONObject(id);
            HistoryState state = decodeHistory(row);
            if (state != null && id.equals(state.titleId)) putHistory(result, state);
        }
        return result;
    }

    private Map<String, HistoryState> parseHistory(JSONArray rows) {
        Map<String, HistoryState> result = new HashMap<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            MainActivity.Item item = SupabaseLibrarySync.itemFromTitle(SupabaseLibrarySync.relatedTitle(row.opt("titles")));
            SupabaseLibrarySync.TitleIdentity id = SupabaseLibrarySync.identityFor(item);
            long time = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            String titleId = row.optString("title_id", "");
            if (item != null && id != null && id.id.equals(titleId) && time > 0L) {
                item.time = time;
                putHistory(result, new HistoryState(titleId, row.optBoolean("is_present", false), time, item));
            }
        }
        return result;
    }

    private Map<String, ProgressState> readLocalProgress(Map<String, HistoryState> history) {
        Map<String, ProgressState> result = new HashMap<>();
        SharedPreferences sync = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONObject stored = readObject(sync, PROGRESS_ROWS);
        Iterator<String> storedKeys = stored.keys();
        while (storedKeys.hasNext()) {
            String key = storedKeys.next();
            ProgressState state = decodeProgress(stored.optJSONObject(key));
            if (state != null && key.equals(progressKey(state.titleId, state.episodeKey))) putProgress(result, state);
        }

        Map<String, MainActivity.Item> titles = knownItems(history);
        SharedPreferences positions = app.getSharedPreferences("playback_position", Context.MODE_PRIVATE);
        SharedPreferences durations = app.getSharedPreferences("playback_duration", Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> entry : positions.getAll().entrySet()) {
            if (!(entry.getValue() instanceof Number)) continue;
            String path = entry.getKey();
            long position = ((Number) entry.getValue()).longValue();
            MainActivity.Item match = findProgressOwner(titles.values(), path);
            SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(match);
            String episode = match == null ? null : episodeKey(match, path);
            if (identity == null || episode == null) continue;
            String key = progressKey(identity.id, episode);
            ProgressState old = result.get(key);
            long time = old == null ? nextAfter(match.time) : old.time;
            long duration = durations.getLong(path, 0L);
            putProgress(result, new ProgressState(identity.id, episode, Math.max(0L, position),
                    Math.max(0L, duration), false, true, time, match));
        }
        return result;
    }

    private Map<String, ProgressState> parseProgress(JSONArray rows) {
        Map<String, ProgressState> result = new HashMap<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            MainActivity.Item item = SupabaseLibrarySync.itemFromTitle(SupabaseLibrarySync.relatedTitle(row.opt("titles")));
            SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
            String id = row.optString("title_id", "");
            String episode = row.optString("episode_key", "");
            long time = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            if (identity == null || !identity.id.equals(id) || !validEpisodeKey(item, episode) || time <= 0L) continue;
            item.time = time;
            long position = Math.max(0L, row.optLong("position_ms", 0L));
            long duration = Math.max(0L, row.optLong("duration_ms", 0L));
            if (duration > 0L) position = Math.min(position, duration);
            putProgress(result, new ProgressState(id, episode, position, duration,
                    row.optBoolean("completed", false), row.optBoolean("is_present", true), time, item));
        }
        return result;
    }

    private Map<String, HiddenState> readLocalHidden(Map<String, HistoryState> history) {
        Map<String, HiddenState> result = new HashMap<>();
        SharedPreferences sync = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONObject stored = readObject(sync, HIDDEN_ROWS);
        Iterator<String> keys = stored.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            HiddenState state = decodeHidden(stored.optJSONObject(key));
            if (state != null && key.equals(state.titleId)) putHidden(result, state);
        }
        SharedPreferences local = app.getSharedPreferences("continue_hidden", Context.MODE_PRIVATE);
        Map<String, MainActivity.Item> titles = knownItems(history);
        for (Map.Entry<String, ?> entry : local.getAll().entrySet()) {
            if (!(entry.getValue() instanceof Boolean) || !((Boolean) entry.getValue())) continue;
            MainActivity.Item item = titles.get(entry.getKey());
            SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
            if (identity == null || result.containsKey(identity.id)) continue;
            putHidden(result, new HiddenState(identity.id, true, nextAfter(item.time), item));
        }
        return result;
    }

    private Map<String, HiddenState> parseHidden(JSONArray rows) {
        Map<String, HiddenState> result = new HashMap<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            MainActivity.Item item = SupabaseLibrarySync.itemFromTitle(SupabaseLibrarySync.relatedTitle(row.opt("titles")));
            SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
            String id = row.optString("title_id", "");
            long time = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            if (identity != null && identity.id.equals(id) && time > 0L) {
                item.time = time;
                putHidden(result, new HiddenState(id, row.optBoolean("is_hidden", false), time, item));
            }
        }
        return result;
    }

    private void applyHistoryClear(Map<String, HistoryState> history, Map<String, ProgressState> progress,
                                   Map<String, HiddenState> hidden, long clearAt) {
        if (clearAt <= 0L) return;
        for (Map.Entry<String, HistoryState> entry : history.entrySet()) {
            HistoryState state = entry.getValue();
            if (state.present && state.time <= clearAt) entry.setValue(new HistoryState(state.titleId, false, clearAt, state.item));
        }
        for (Map.Entry<String, ProgressState> entry : progress.entrySet()) {
            ProgressState state = entry.getValue();
            if (state.time <= clearAt) entry.setValue(new ProgressState(state.titleId, state.episodeKey, 0L,
                    state.durationMs, false, false, clearAt, state.item));
        }
        for (Map.Entry<String, HiddenState> entry : hidden.entrySet()) {
            HiddenState state = entry.getValue();
            if (state.hidden && state.time <= clearAt) entry.setValue(new HiddenState(state.titleId, false,
                    nextAfter(clearAt), state.item));
        }
    }

    private void applyHistoryRemovalsToProgress(Map<String, HistoryState> history, Map<String, ProgressState> progress) {
        for (Map.Entry<String, ProgressState> entry : progress.entrySet()) {
            ProgressState state = entry.getValue();
            HistoryState titleHistory = history.get(state.titleId);
            if (titleHistory != null && !titleHistory.present && state.present) {
                long removedAt = nextAfter(Math.max(state.time, titleHistory.time));
                entry.setValue(new ProgressState(state.titleId, state.episodeKey, 0L, state.durationMs,
                        false, false, removedAt, state.item));
            }
        }
    }

    private void writeLocalHistory(Map<String, HistoryState> states, long clearAt) throws IOException {
        ArrayList<MainActivity.Item> server1 = new ArrayList<>();
        ArrayList<MainActivity.Item> server2 = new ArrayList<>();
        JSONObject tombstones = new JSONObject();
        for (HistoryState state : states.values()) {
            if (state.item == null) continue;
            if (state.present) {
                state.item.time = state.time;
                (MovyApi.isMovy(state.item.url) ? server2 : server1).add(state.item);
            } else {
                try { tombstones.put(state.titleId, encodeHistory(state)); }
                catch (JSONException ignored) { }
            }
        }
        Comparator<MainActivity.Item> newest = (a, b) -> Long.compare(b.time, a.time);
        Collections.sort(server1, newest);
        Collections.sort(server2, newest);
        if (!saveItems(app.getSharedPreferences(HISTORY_PREFS[0], Context.MODE_PRIVATE), server1)
                || !saveItems(app.getSharedPreferences(HISTORY_PREFS[1], Context.MODE_PRIVATE), server2)) {
            throw new IOException("Could not save merged History locally; no cloud data was deleted.");
        }
        SharedPreferences.Editor editor = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(HISTORY_TOMBSTONES, tombstones.toString());
        if (clearAt > 0L) editor.putLong(HISTORY_CLEAR_AT, clearAt);
        if (!editor.commit()) throw new IOException("Could not save History tombstones locally.");
    }

    private void writeLocalProgress(Map<String, ProgressState> states) throws IOException {
        JSONObject encoded = new JSONObject();
        SharedPreferences positions = app.getSharedPreferences("playback_position", Context.MODE_PRIVATE);
        SharedPreferences durations = app.getSharedPreferences("playback_duration", Context.MODE_PRIVATE);
        SharedPreferences resumes = app.getSharedPreferences("resume_titles", Context.MODE_PRIVATE);
        SharedPreferences.Editor positionEdit = positions.edit();
        SharedPreferences.Editor durationEdit = durations.edit();
        SharedPreferences.Editor resumeEdit = resumes.edit();
        Map<String, ProgressState> bestByTitle = new HashMap<>();
        for (Map.Entry<String, ProgressState> entry : states.entrySet()) {
            ProgressState state = entry.getValue();
            if (state.item == null) continue;
            try { encoded.put(entry.getKey(), encodeProgress(state)); }
            catch (JSONException ignored) { }
            String path = playbackPath(state.item, state.episodeKey);
            if (path == null) continue;
            if (state.present && !state.completed && state.positionMs > 0L) {
                positionEdit.putLong(path, state.positionMs);
                if (state.durationMs > 0L) durationEdit.putLong(path, state.durationMs);
                ProgressState old = bestByTitle.get(state.titleId);
                String preferredPath = resumes.getString(state.item.url, "");
                String oldPath = old == null ? null : playbackPath(old.item, old.episodeKey);
                boolean preferred = path.equals(preferredPath);
                boolean oldPreferred = oldPath != null && oldPath.equals(preferredPath);
                if (old == null || state.time > old.time
                        || (state.time == old.time && (preferred != oldPreferred
                        ? preferred : state.episodeKey.compareTo(old.episodeKey) > 0))) {
                    bestByTitle.put(state.titleId, state);
                }
            } else {
                positionEdit.remove(path);
                if (state.durationMs > 0L) durationEdit.putLong(path, state.durationMs);
            }
            resumeEdit.remove(state.item.url);
        }
        for (ProgressState state : bestByTitle.values()) {
            String path = playbackPath(state.item, state.episodeKey);
            if (path != null) resumeEdit.putString(state.item.url, path);
        }
        SharedPreferences.Editor syncEdit = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(PROGRESS_ROWS, encoded.toString());
        if (!positionEdit.commit() || !durationEdit.commit() || !resumeEdit.commit() || !syncEdit.commit()) {
            throw new IOException("Could not save merged playback progress locally.");
        }
    }

    private void writeLocalHidden(Map<String, HiddenState> states, Map<String, HistoryState> history) throws IOException {
        JSONObject encoded = new JSONObject();
        SharedPreferences hidden = app.getSharedPreferences("continue_hidden", Context.MODE_PRIVATE);
        SharedPreferences.Editor hiddenEdit = hidden.edit();
        for (HiddenState state : states.values()) {
            if (state.item == null) continue;
            try { encoded.put(state.titleId, encodeHidden(state)); }
            catch (JSONException ignored) { }
            if (state.hidden) hiddenEdit.putBoolean(state.item.url, true);
            else hiddenEdit.remove(state.item.url);
        }
        if (!hiddenEdit.commit() || !app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(HIDDEN_ROWS, encoded.toString()).commit()) {
            throw new IOException("Could not save Continue Watching visibility locally.");
        }
    }

    private ArrayList<JSONObject> collectTitleRows(String userId, Map<String, HistoryState> history,
                                                    Map<String, ProgressState> progress, Map<String, HiddenState> hidden) {
        Map<String, JSONObject> rows = new HashMap<>();
        for (HistoryState state : history.values()) addTitlePayload(rows, userId, state.item);
        for (ProgressState state : progress.values()) addTitlePayload(rows, userId, state.item);
        for (HiddenState state : hidden.values()) addTitlePayload(rows, userId, state.item);
        return new ArrayList<>(rows.values());
    }

    private static void addTitlePayload(Map<String, JSONObject> rows, String userId, MainActivity.Item item) {
        JSONObject row = SupabaseLibrarySync.titlePayload(userId, item);
        if (row != null) rows.put(row.optString("id", ""), row);
    }

    private static JSONArray historyPayload(String userId, Map<String, HistoryState> states) {
        JSONArray rows = new JSONArray();
        for (HistoryState state : states.values()) {
            if (state.item == null || state.time <= 0L) continue;
            JSONObject row = new JSONObject();
            try {
                row.put("user_id", userId);
                row.put("title_id", state.titleId);
                row.put("is_present", state.present);
                row.put("client_updated_at", SupabaseLibrarySync.formatTimestamp(state.time));
                rows.put(row);
            } catch (JSONException ignored) { }
        }
        return rows;
    }

    private static JSONArray progressPayload(String userId, Map<String, ProgressState> states) {
        JSONArray rows = new JSONArray();
        for (ProgressState state : states.values()) {
            if (state.item == null || state.time <= 0L || !validEpisodeKey(state.item, state.episodeKey)) continue;
            JSONObject row = new JSONObject();
            try {
                row.put("user_id", userId);
                row.put("title_id", state.titleId);
                row.put("episode_key", state.episodeKey);
                row.put("position_ms", state.positionMs);
                row.put("duration_ms", state.durationMs > 0L ? state.durationMs : JSONObject.NULL);
                row.put("completed", state.completed);
                row.put("is_present", state.present);
                row.put("client_updated_at", SupabaseLibrarySync.formatTimestamp(state.time));
                rows.put(row);
            } catch (JSONException ignored) { }
        }
        return rows;
    }

    private static JSONArray hiddenPayload(String userId, Map<String, HiddenState> states) {
        JSONArray rows = new JSONArray();
        for (HiddenState state : states.values()) {
            if (state.item == null || state.time <= 0L) continue;
            JSONObject row = new JSONObject();
            try {
                row.put("user_id", userId);
                row.put("title_id", state.titleId);
                row.put("is_hidden", state.hidden);
                row.put("client_updated_at", SupabaseLibrarySync.formatTimestamp(state.time));
                rows.put(row);
            } catch (JSONException ignored) { }
        }
        return rows;
    }

    private static void applyAcceptedTimes(JSONArray rows, Map<String, HistoryState> history,
                                          Map<String, ProgressState> progress) {
        applyAcceptedTimes(rows, history, progress, null);
    }

    private static void applyAcceptedTimes(JSONArray rows, Map<String, HistoryState> history,
                                          Map<String, ProgressState> progress, Map<String, HiddenState> hidden) {
        if (rows == null) return;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String id = row.optString("title_id", "");
            long time = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            if (time <= 0L) continue;
            if (history != null) {
                HistoryState state = history.get(id);
                if (state != null) history.put(id, new HistoryState(id, state.present, time, state.item));
            } else if (progress != null) {
                String key = progressKey(id, row.optString("episode_key", ""));
                ProgressState state = progress.get(key);
                if (state != null) progress.put(key, new ProgressState(state.titleId, state.episodeKey,
                        state.positionMs, state.durationMs, state.completed, state.present, time, state.item));
            } else if (hidden != null) {
                HiddenState state = hidden.get(id);
                if (state != null) hidden.put(id, new HiddenState(id, state.hidden, time, state.item));
            }
        }
    }

    private static void normalizeHistoryTimes(Map<String, HistoryState> current,
                                              Map<String, HistoryState> submitted, JSONArray accepted) {
        if (accepted == null) return;
        for (int i = 0; i < accepted.length(); i++) {
            JSONObject row = accepted.optJSONObject(i);
            if (row == null) continue;
            String id = row.optString("title_id", "");
            long serverTime = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            boolean serverPresent = row.optBoolean("is_present", false);
            HistoryState sent = submitted.get(id), local = current.get(id);
            if (serverTime > 0L && sent != null && local != null && local.time == sent.time
                    && local.present == sent.present && serverPresent == sent.present) {
                current.put(id, new HistoryState(id, local.present, serverTime, local.item));
            }
        }
    }

    private static void normalizeProgressTimes(Map<String, ProgressState> current,
                                               Map<String, ProgressState> submitted, JSONArray accepted) {
        if (accepted == null) return;
        for (int i = 0; i < accepted.length(); i++) {
            JSONObject row = accepted.optJSONObject(i);
            if (row == null) continue;
            String id = row.optString("title_id", ""), episode = row.optString("episode_key", "");
            long serverTime = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            String key = progressKey(id, episode);
            ProgressState sent = submitted.get(key), local = current.get(key);
            boolean same = sent != null && local != null && local.time == sent.time
                    && local.present == sent.present && local.completed == sent.completed
                    && local.positionMs == sent.positionMs && local.durationMs == sent.durationMs;
            if (serverTime > 0L && same && row.optBoolean("is_present", true) == sent.present
                    && row.optBoolean("completed", false) == sent.completed
                    && row.optLong("position_ms", 0L) == sent.positionMs) {
                current.put(key, new ProgressState(id, episode, local.positionMs, local.durationMs,
                        local.completed, local.present, serverTime, local.item));
            }
        }
    }

    private static void normalizeHiddenTimes(Map<String, HiddenState> current,
                                             Map<String, HiddenState> submitted, JSONArray accepted) {
        if (accepted == null) return;
        for (int i = 0; i < accepted.length(); i++) {
            JSONObject row = accepted.optJSONObject(i);
            if (row == null) continue;
            String id = row.optString("title_id", "");
            long serverTime = SupabaseLibrarySync.parseTimestamp(row.optString("client_updated_at", ""));
            boolean serverHidden = row.optBoolean("is_hidden", false);
            HiddenState sent = submitted.get(id), local = current.get(id);
            if (serverTime > 0L && sent != null && local != null && local.time == sent.time
                    && local.hidden == sent.hidden && serverHidden == sent.hidden) {
                current.put(id, new HiddenState(id, local.hidden, serverTime, local.item));
            }
        }
    }

    private static Map<String, HistoryState> mergeHistory(Map<String, HistoryState> local, Map<String, HistoryState> remote) {
        Map<String, HistoryState> out = new HashMap<>(remote);
        for (HistoryState state : local.values()) putHistory(out, state);
        return out;
    }

    private static Map<String, ProgressState> mergeProgress(Map<String, ProgressState> local, Map<String, ProgressState> remote) {
        Map<String, ProgressState> out = new HashMap<>(remote);
        for (ProgressState state : local.values()) putProgress(out, state);
        return out;
    }

    private static Map<String, HiddenState> mergeHidden(Map<String, HiddenState> local, Map<String, HiddenState> remote) {
        Map<String, HiddenState> out = new HashMap<>(remote);
        for (HiddenState state : local.values()) putHidden(out, state);
        return out;
    }

    static boolean historyLocalWinsForTest(long localTime, boolean localPresent, long remoteTime, boolean remotePresent) {
        return localTime > remoteTime || (localTime == remoteTime && !localPresent && remotePresent);
    }

    static boolean progressLocalWinsForTest(long localTime, boolean localPresent, boolean localCompleted, long localPosition,
                                            long remoteTime, boolean remotePresent, boolean remoteCompleted, long remotePosition) {
        if (localTime != remoteTime) return localTime > remoteTime;
        if (localPresent != remotePresent) return !localPresent;
        if (localCompleted != remoteCompleted) return localCompleted;
        return localPosition > remotePosition;
    }

    static boolean hiddenLocalWinsForTest(long localTime, boolean localHidden, long remoteTime, boolean remoteHidden) {
        return localTime > remoteTime || (localTime == remoteTime && localHidden && !remoteHidden);
    }

    private static void putHistory(Map<String, HistoryState> rows, HistoryState value) {
        HistoryState old = rows.get(value.titleId);
        if (old == null || historyLocalWinsForTest(value.time, value.present, old.time, old.present)) rows.put(value.titleId, value);
    }

    private static void putProgress(Map<String, ProgressState> rows, ProgressState value) {
        String key = progressKey(value.titleId, value.episodeKey);
        ProgressState old = rows.get(key);
        if (old == null || progressLocalWinsForTest(value.time, value.present, value.completed, value.positionMs,
                old.time, old.present, old.completed, old.positionMs)) rows.put(key, value);
    }

    private static void putHidden(Map<String, HiddenState> rows, HiddenState value) {
        HiddenState old = rows.get(value.titleId);
        if (old == null || hiddenLocalWinsForTest(value.time, value.hidden, old.time, old.hidden)) rows.put(value.titleId, value);
    }

    private Map<String, MainActivity.Item> knownItems(Map<String, HistoryState> history) {
        Map<String, MainActivity.Item> items = new HashMap<>();
        for (HistoryState state : history.values()) if (state.item != null) items.put(state.item.url, state.item);
        for (String pref : LIST_PREFS) {
            try {
                JSONArray rows = new JSONArray(app.getSharedPreferences(pref, Context.MODE_PRIVATE).getString("items", "[]"));
                for (int i = 0; i < rows.length(); i++) {
                    MainActivity.Item item = decodeItem(rows.optJSONObject(i));
                    if (item != null) items.put(item.url, item);
                }
            } catch (Exception ignored) { }
        }
        return items;
    }

    private MainActivity.Item findProgressOwner(Iterable<MainActivity.Item> items, String path) {
        MainActivity.Item match = null;
        for (MainActivity.Item item : items) {
            if (MainActivity.progressBelongsToTitle(item.url, path)) {
                if (match != null && !match.url.equals(item.url)) return null;
                match = item;
            }
        }
        return match;
    }

    private MainActivity.Item findItemByUrl(String url, Map<String, HistoryState> history) {
        for (HistoryState state : history.values()) if (state.item != null && url.equals(state.item.url)) return state.item;
        for (String pref : LIST_PREFS) {
            try {
                JSONArray rows = new JSONArray(app.getSharedPreferences(pref, Context.MODE_PRIVATE).getString("items", "[]"));
                for (int i = 0; i < rows.length(); i++) {
                    MainActivity.Item item = decodeItem(rows.optJSONObject(i));
                    if (item != null && url.equals(item.url)) return item;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static MainActivity.Item findItem(Context context, String url) {
        for (String pref : new String[]{"watch_history", "watch_history_movy", "my_list", "my_list_movy"}) {
            try {
                JSONArray rows = new JSONArray(context.getApplicationContext().getSharedPreferences(pref, Context.MODE_PRIVATE).getString("items", "[]"));
                for (int i = 0; i < rows.length(); i++) {
                    MainActivity.Item item = decodeItem(rows.optJSONObject(i));
                    if (item != null && url.equals(item.url)) return item;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    static String episodeKey(MainActivity.Item title, String playbackPath) {
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(title);
        if (identity == null || !MainActivity.progressBelongsToTitle(title.url, playbackPath)) return null;
        Uri uri = MainActivity.canonicalTitleUri(playbackPath);
        if (uri == null) return null;
        if ("Server 1".equals(identity.source)) {
            if (uri.getQuery() != null || uri.getFragment() != null) return null;
            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("/s-([0-9]{1,3})/ep-([1-9][0-9]{0,3})/?$").matcher(uri.getPath());
            if (matcher.find()) return "s" + matcher.group(1) + "e" + matcher.group(2);
            return uri.getPath().equals(identity.path) ? "" : null;
        }
        if (uri.getPath().startsWith("/tv/")) {
            for (String name : uri.getQueryParameterNames())
                if (!"season".equals(name) && !"episode".equals(name)) return null;
            String season = uri.getQueryParameter("season");
            String episode = uri.getQueryParameter("episode");
            if (season == null && episode == null) return "s1e1";
            if (season == null || episode == null || !season.matches("[0-9]{1,3}")
                    || !episode.matches("[1-9][0-9]{0,3}")) return null;
            return "s" + season + "e" + episode;
        }
        return uri.getPath().equals(identity.path) && uri.getQuery() == null ? "" : null;
    }

    static boolean validEpisodeKey(MainActivity.Item title, String key) {
        if (title == null || key == null) return false;
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(title);
        if (identity == null) return false;
        if (key.isEmpty()) return !"Server 1".equals(identity.source) || !identity.path.startsWith("/series/");
        return key.matches("s[0-9]{1,3}e[1-9][0-9]{0,3}")
                && (identity.path.startsWith("/series/") || identity.path.startsWith("/tv/"));
    }

    static String playbackPath(MainActivity.Item item, String episode) {
        if (item == null || !validEpisodeKey(item, episode)) return null;
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (identity == null) return null;
        if (episode.isEmpty()) return item.url;
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("s([0-9]{1,3})e([1-9][0-9]{0,3})").matcher(episode);
        if (!matcher.matches()) return null;
        if ("Server 1".equals(identity.source)) return "https://play4u.org" + identity.path
                + "/s-" + matcher.group(1) + "/ep-" + matcher.group(2);
        return "https://www.movy.sx" + identity.path + "?season=" + matcher.group(1) + "&episode=" + matcher.group(2);
    }

    private static String progressKey(String id, String episode) { return id + "|" + (episode == null ? "" : episode); }
    private static long nextAfter(long time) {
        long now = System.currentTimeMillis();
        long next = time == Long.MAX_VALUE ? Long.MAX_VALUE : time + 1L;
        return Math.max(now, next);
    }

    private static JSONObject encodeHistory(HistoryState state) throws JSONException {
        JSONObject row = new JSONObject();
        row.put("title_id", state.titleId); row.put("present", state.present); row.put("time", state.time);
        row.put("item", encodeItem(state.item)); return row;
    }
    private static JSONObject encodeProgress(ProgressState state) throws JSONException {
        JSONObject row = new JSONObject();
        row.put("title_id", state.titleId); row.put("episode_key", state.episodeKey); row.put("position_ms", state.positionMs);
        row.put("duration_ms", state.durationMs); row.put("completed", state.completed); row.put("present", state.present);
        row.put("time", state.time); row.put("item", encodeItem(state.item)); return row;
    }
    private static JSONObject encodeHidden(HiddenState state) throws JSONException {
        JSONObject row = new JSONObject(); row.put("title_id", state.titleId); row.put("hidden", state.hidden);
        row.put("time", state.time); row.put("item", encodeItem(state.item)); return row;
    }
    private static JSONObject encodeItem(MainActivity.Item item) throws JSONException {
        JSONObject row = new JSONObject(); row.put("title", item.title); row.put("url", item.url);
        row.put("img", item.img == null ? "" : item.img); row.put("year", item.year == null ? "" : item.year);
        row.put("time", item.time); return row;
    }
    private static MainActivity.Item decodeItem(JSONObject row) {
        if (row == null) return null;
        MainActivity.Item item = new MainActivity.Item(row.optString("title", ""), row.optString("url", ""),
                row.optString("img", ""), row.optString("year", ""));
        item.time = row.optLong("time", 0L); return item;
    }
    private static HistoryState decodeHistory(JSONObject row) {
        if (row == null) return null;
        MainActivity.Item item = decodeItem(row.optJSONObject("item"));
        String id = row.optString("title_id", "");
        long time = row.optLong("time", 0L);
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        return item == null || identity == null || !id.equals(identity.id) || time <= 0L
                ? null : new HistoryState(id, row.optBoolean("present", false), time, item);
    }
    private static ProgressState decodeProgress(JSONObject row) {
        if (row == null) return null;
        MainActivity.Item item = decodeItem(row.optJSONObject("item"));
        String id = row.optString("title_id", ""), episode = row.optString("episode_key", "");
        long time = row.optLong("time", 0L);
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        if (item == null || identity == null || !id.equals(identity.id) || !validEpisodeKey(item, episode) || time <= 0L) return null;
        long duration = Math.max(0L, row.optLong("duration_ms", 0L));
        long position = Math.max(0L, row.optLong("position_ms", 0L));
        if (duration > 0L) position = Math.min(position, duration);
        return new ProgressState(id, episode, position, duration, row.optBoolean("completed", false),
                row.optBoolean("present", true), time, item);
    }
    private static HiddenState decodeHidden(JSONObject row) {
        if (row == null) return null;
        MainActivity.Item item = decodeItem(row.optJSONObject("item"));
        String id = row.optString("title_id", "");
        long time = row.optLong("time", 0L);
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);
        return item == null || identity == null || !id.equals(identity.id) || time <= 0L
                ? null : new HiddenState(id, row.optBoolean("hidden", false), time, item);
    }
    private static JSONObject readObject(SharedPreferences prefs, String key) {
        try { return new JSONObject(prefs.getString(key, "{}")); }
        catch (Exception ignored) { return new JSONObject(); }
    }
    private static boolean saveItems(SharedPreferences prefs, List<MainActivity.Item> items) {
        JSONArray rows = new JSONArray();
        for (MainActivity.Item item : items) try { rows.put(encodeItem(item)); } catch (JSONException ignored) { }
        return prefs.edit().putString("items", rows.toString()).commit();
    }
    private static boolean isEmpty(String value) { return value == null || value.trim().isEmpty(); }

    private static final class HistoryState {
        final String titleId; final boolean present; final long time; final MainActivity.Item item;
        HistoryState(String id, boolean present, long time, MainActivity.Item item) {
            this.titleId=id; this.present=present; this.time=time; this.item=item;
        }
    }
    private static final class ProgressState {
        final String titleId, episodeKey; final long positionMs, durationMs; final boolean completed, present;
        final long time; final MainActivity.Item item;
        ProgressState(String id, String episode, long pos, long duration, boolean completed, boolean present, long time, MainActivity.Item item) {
            this.titleId=id; this.episodeKey=episode; this.positionMs=pos; this.durationMs=duration;
            this.completed=completed; this.present=present; this.time=time; this.item=item;
        }
    }
    private static final class HiddenState {
        final String titleId; final boolean hidden; final long time; final MainActivity.Item item;
        HiddenState(String id, boolean hidden, long time, MainActivity.Item item) {
            this.titleId=id; this.hidden=hidden; this.time=time; this.item=item;
        }
    }
    public static final class SyncResult {
        public final int historyTitles, resumableEpisodes, hiddenTitles;
        SyncResult(int history, int progress, int hidden) { historyTitles=history; resumableEpisodes=progress; hiddenTitles=hidden; }
    }
}
