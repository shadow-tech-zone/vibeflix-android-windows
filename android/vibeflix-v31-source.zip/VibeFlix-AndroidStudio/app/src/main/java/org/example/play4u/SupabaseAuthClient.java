package org.example.play4u;

import android.util.Base64;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Small HTTPS-only Supabase Auth client using the publishable key and password grant. */
public final class SupabaseAuthClient {
    private static final int CONNECT_TIMEOUT_MS = 12000;
    private static final int READ_TIMEOUT_MS = 15000;
    private static final int MAX_RESPONSE_BYTES = 64 * 1024;

    private final String baseUrl;
    private final String publishableKey;

    public SupabaseAuthClient() {
        this(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_PUBLISHABLE_KEY);
    }

    SupabaseAuthClient(String baseUrl, String publishableKey) {
        this.baseUrl = trimTrailingSlash(baseUrl);
        this.publishableKey = publishableKey == null ? "" : publishableKey.trim();
    }

    public boolean isConfigured() {
        if (!isClientKey(publishableKey)) return false;
        try {
            URL url = new URL(baseUrl);
            return "https".equalsIgnoreCase(url.getProtocol()) && url.getHost() != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean isClientKey(String key) {
        if (key == null || key.trim().isEmpty()) return false;
        if (key.startsWith("sb_publishable_") && key.length() > "sb_publishable_".length()) return true;
        if (key.startsWith("sb_secret_")) return false;
        String[] parts = key.split("\\.");
        if (parts.length != 3) return false;
        try {
            byte[] payload = Base64.decode(parts[1], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            JSONObject claims = new JSONObject(new String(payload, StandardCharsets.UTF_8));
            return "anon".equals(claims.optString("role", ""));
        } catch (Exception ignored) {
            return false;
        }
    }

    public SupabaseSessionStore.Session signIn(String email, String password) throws IOException {
        if (!isConfigured()) throw new AuthException("Cloud sign-in is not configured in this build.", 0);
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            throw new AuthException("Enter both email and password.", 0);
        }
        JSONObject body = new JSONObject();
        try {
            body.put("email", email.trim());
            body.put("password", password);
        } catch (JSONException error) {
            throw new IOException("Could not prepare the sign-in request.", error);
        }
        JSONObject response = request("/auth/v1/token?grant_type=password", body, null);
        return parseSession(response);
    }

    public SupabaseSessionStore.Session refresh(String refreshToken) throws IOException {
        if (!isConfigured()) throw new AuthException("Cloud sign-in is not configured in this build.", 0);
        if (refreshToken == null || refreshToken.trim().isEmpty()) {
            throw new AuthException("The saved session has expired. Sign in again.", 401);
        }
        JSONObject body = new JSONObject();
        try {
            body.put("refresh_token", refreshToken);
        } catch (JSONException error) {
            throw new IOException("Could not prepare the session refresh request.", error);
        }
        return parseSession(request("/auth/v1/token?grant_type=refresh_token", body, null));
    }

    public void signOut(String accessToken) throws IOException {
        if (!isConfigured() || accessToken == null || accessToken.trim().isEmpty()) return;
        request("/auth/v1/logout", new JSONObject(), accessToken);
    }

    private JSONObject request(String path, JSONObject payload, String accessToken) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(baseUrl + path).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setUseCaches(false);
            connection.setDoOutput(true);
            connection.setRequestProperty("apikey", publishableKey);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            if (accessToken != null && !accessToken.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + accessToken);
            }
            byte[] requestBody = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(requestBody.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(requestBody);
            }
            int status = connection.getResponseCode();
            InputStream responseStream = status >= 200 && status < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            byte[] responseBytes = responseStream == null ? new byte[0] : readBounded(responseStream);
            if (status < 200 || status >= 300) {
                throw new AuthException(userMessage(status), status);
            }
            if (responseBytes.length == 0) return new JSONObject();
            try {
                return new JSONObject(new String(responseBytes, StandardCharsets.UTF_8));
            } catch (JSONException error) {
                throw new IOException("Supabase returned an invalid response.", error);
            }
        } catch (AuthException error) {
            throw error;
        } catch (IOException error) {
            throw new IOException("Could not reach Supabase. Check the connection and try again.", error);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static byte[] readBounded(InputStream input) throws IOException {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int total = 0;
            int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) throw new IOException("Supabase response was too large.");
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        }
    }

    private static SupabaseSessionStore.Session parseSession(JSONObject response) throws IOException {
        String accessToken = response.optString("access_token", "");
        String refreshToken = response.optString("refresh_token", "");
        JSONObject user = response.optJSONObject("user");
        String userId = user == null ? "" : user.optString("id", "");
        long expiresAtSeconds = response.optLong("expires_at", 0L);
        long expiresAtMs = expiresAtSeconds > 0
                ? expiresAtSeconds * 1000L
                : System.currentTimeMillis() + Math.max(60L, response.optLong("expires_in", 3600L)) * 1000L;
        if (accessToken.isEmpty() || refreshToken.isEmpty() || userId.isEmpty()) {
            throw new IOException("Supabase did not return a complete authenticated session.");
        }
        return new SupabaseSessionStore.Session(accessToken, refreshToken, userId, expiresAtMs);
    }

    private static String userMessage(int status) {
        if (status == 400 || status == 401) {
            return "Sign-in failed. Check the email, password, and email confirmation for this account.";
        }
        if (status == 429) return "Too many sign-in attempts. Wait a while and try again.";
        return "Supabase sign-in failed (HTTP " + status + "). Try again later.";
    }

    private static String trimTrailingSlash(String value) {
        if (value == null) return "";
        String result = value.trim();
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }

    public static final class AuthException extends IOException {
        public final int statusCode;

        AuthException(String message, int statusCode) {
            super(message);
            this.statusCode = statusCode;
        }
    }
}
