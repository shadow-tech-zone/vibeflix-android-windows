package org.example.play4u;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/** Local-first, explicitly enabled My List merge for one Supabase account. */
public final class SupabaseLibrarySync {
    private static final String SYNC_PREFS = "vibeflix_supabase_library_sync";
    private static final String ENABLED_USER = "library_sync_user_id";
    private static final String CONSENT_VERSION = "library_sync_consent_version";
    private static final int CURRENT_CONSENT_VERSION = 2;
    private static final String TOMBSTONES = "my_list_tombstones_v1";
    private static final String SERVER1_PREFS = "my_list";
    private static final String SERVER2_PREFS = "my_list_movy";
    private static final Object LOCAL_LOCK = new Object();

    private final Context appContext;
    private final SupabaseRestClient rest;

    public SupabaseLibrarySync(Context context) {
        this(context, new SupabaseRestClient());
    }

    SupabaseLibrarySync(Context context, SupabaseRestClient rest) {
        appContext = context.getApplicationContext();
        this.rest = rest;
    }

    static Object localLock() { return LOCAL_LOCK; }

    /** Versioned consent explicitly covers My List, History, resume, and Continue Watching. */
    public static void enableFor(Context context, String userId) {
        if (context == null || isEmpty(userId)) return;
        context.getApplicationContext().getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE)
                .edit().putString(ENABLED_USER, userId)
                .putInt(CONSENT_VERSION, CURRENT_CONSENT_VERSION).commit();
    }

    public static boolean isEnabledFor(Context context, String userId) {
        if (context == null || isEmpty(userId)) return false;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE);
        return userId.equals(prefs.getString(ENABLED_USER, ""))
                && prefs.getInt(CONSENT_VERSION, 0) >= CURRENT_CONSENT_VERSION;
    }

    /** Revoke this account's opt-in without deleting local or already-synced cloud data. */
    public static boolean disableFor(Context context, String userId) {
        if (context == null || isEmpty(userId)) return false;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE);
        synchronized (LOCAL_LOCK) {
            if (!userId.equals(prefs.getString(ENABLED_USER, ""))) return false;
            return prefs.edit().remove(ENABLED_USER).remove(CONSENT_VERSION).commit();
        }
    }

    /** A per-title monotonic local timestamp, even when two taps share one clock millisecond. */
    public static long nextMyListTimestamp(Context context, MainActivity.Item item) {
        long previous = item == null ? 0L : Math.max(0L, item.time);
        TitleIdentity identity = identityFor(item);
        if (context != null && identity != null) {
            Context app = context.getApplicationContext();
            synchronized (LOCAL_LOCK) {
                SharedPreferences sync = app.getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE);
                JSONObject tombstone = readTombstones(sync).optJSONObject(identity.id);
                if (tombstone != null) previous = Math.max(previous, tombstone.optLong("time", 0L));
                for (String name : new String[]{SERVER1_PREFS, SERVER2_PREFS}) {
                    SharedPreferences prefs = app.getSharedPreferences(name, Context.MODE_PRIVATE);
                    try {
                        JSONArray rows = new JSONArray(prefs.getString("items", "[]"));
                        for (int i = 0; i < rows.length(); i++) {
                            JSONObject row = rows.optJSONObject(i);
                            MainActivity.Item existing = decodeItem(row);
                            TitleIdentity existingId = existing == null ? null : identityFor(existing);
                            if (row != null && existingId != null && identity.id.equals(existingId.id)) {
                                previous = Math.max(previous, row.optLong("time", 0L));
                            }
                        }
                    } catch (JSONException ignored) {
                        // Ignore only the malformed representation; preserve other local timestamp sources.
                    }
                }
            }
        }
        long next = previous == Long.MAX_VALUE ? Long.MAX_VALUE : previous + 1L;
        return Math.max(System.currentTimeMillis(), next);
    }

    /** Keep a durable tombstone so an offline removal cannot reappear on another device. */
    public static void recordMyListTombstone(Context context, MainActivity.Item item, long updatedAtMs) {
        if (context == null || item == null) return;
        TitleIdentity identity = identityFor(item);
        if (identity == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE);
        synchronized (LOCAL_LOCK) {
            JSONObject rows = readTombstones(prefs);
            try {
                rows.put(identity.id, encodeItem(item, updatedAtMs));
                prefs.edit().putString(TOMBSTONES, rows.toString()).commit();
            } catch (JSONException ignored) {
                // The on-device collection remains authoritative if metadata cannot be encoded.
            }
        }
    }

    public static void clearMyListTombstone(Context context, MainActivity.Item item) {
        if (context == null || item == null) return;
        TitleIdentity identity = identityFor(item);
        if (identity == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE);
        synchronized (LOCAL_LOCK) {
            JSONObject rows = readTombstones(prefs);
            rows.remove(identity.id);
            prefs.edit().putString(TOMBSTONES, rows.toString()).commit();
        }
    }

    /** Pulls, compares, and writes My List state without replacing local data on failure. */
    public SyncResult syncMyList(SupabaseSessionStore.Session session) throws IOException {
        if (session == null || isEmpty(session.userId) || isEmpty(session.accessToken)) {
            throw new IOException("Sign in before syncing My List.");
        }
        if (!isEnabledFor(appContext, session.userId)) {
            throw new IOException("Enable My List sync on this device before syncing.");
        }

        JSONArray remoteRows = rest.fetchMyList(session.userId, session.accessToken);
        Map<String, ListState> remote = parseRemoteRows(remoteRows);
        Map<String, ListState> merged = new HashMap<>();
        Map<String, ListState> localWins = new HashMap<>();
        ArrayList<JSONObject> titleWrites = new ArrayList<>();
        ArrayList<JSONObject> listWrites = new ArrayList<>();

        synchronized (LOCAL_LOCK) {
            Map<String, ListState> local = readLocalStates();
            java.util.HashSet<String> keys = new java.util.HashSet<>();
            keys.addAll(local.keySet());
            keys.addAll(remote.keySet());
            for (String id : keys) {
                ListState localState = local.get(id);
                ListState remoteState = remote.get(id);
                if (localState != null && remoteState == null) {
                    merged.put(id, localState);
                    localWins.put(id, localState);
                } else if (localState == null) {
                    merged.put(id, remoteState);
                } else if (localWins(localState, remoteState)) {
                    merged.put(id, localState);
                    localWins.put(id, localState);
                } else {
                    merged.put(id, remoteState);
                }
            }

            writeLocalStates(merged);
            for (ListState state : localWins.values()) {
                JSONObject title = titlePayload(session.userId, state.item);
                JSONObject list = listPayload(session.userId, state);
                if (title != null && list != null) {
                    titleWrites.add(title);
                    listWrites.add(list);
                }
            }
        }

        // Title rows must exist before the My List foreign key is upserted.
        rest.upsertTitles(toJsonArray(titleWrites), session.accessToken);
        JSONArray acceptedRows = rest.upsertMyList(toJsonArray(listWrites), session.accessToken);
        applyServerTimestamps(acceptedRows, localWins);
        int active = 0;
        for (ListState state : merged.values()) if (state.present) active++;
        return new SyncResult(active, merged.size() - active, localWins.size());
    }

    private void applyServerTimestamps(JSONArray acceptedRows, Map<String, ListState> submitted) {
        if (acceptedRows == null || acceptedRows.length() == 0 || submitted.isEmpty()) return;
        Map<String, ListState> accepted = new HashMap<>();
        for (int i = 0; i < acceptedRows.length(); i++) {
            JSONObject row = acceptedRows.optJSONObject(i);
            if (row == null) continue;
            String id = row.optString("title_id", "");
            long time = parseTimestamp(row.optString("client_updated_at", ""));
            if (!isEmpty(id) && time > 0) accepted.put(id,
                    new ListState(id, row.optBoolean("is_present", false), time, null));
        }
        if (accepted.isEmpty()) return;
        synchronized (LOCAL_LOCK) {
            SharedPreferences server1 = appContext.getSharedPreferences(SERVER1_PREFS, Context.MODE_PRIVATE);
            SharedPreferences server2 = appContext.getSharedPreferences(SERVER2_PREFS, Context.MODE_PRIVATE);
            updateItemTimes(server1, accepted, submitted);
            updateItemTimes(server2, accepted, submitted);
            SharedPreferences sync = appContext.getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE);
            JSONObject tombstones = readTombstones(sync);
            boolean changed = false;
            for (String id : accepted.keySet()) {
                ListState sent = submitted.get(id);
                ListState server = accepted.get(id);
                JSONObject row = tombstones.optJSONObject(id);
                if (sent == null || sent.present || server.present || row == null
                        || row.optLong("time", 0L) != sent.updatedAtMs) continue;
                try {
                    row.put("time", server.updatedAtMs);
                    changed = true;
                } catch (JSONException ignored) {
                    // Keep the local timestamp if it cannot be rewritten.
                }
            }
            if (changed) sync.edit().putString(TOMBSTONES, tombstones.toString()).commit();
        }
    }

    private static void updateItemTimes(SharedPreferences prefs, Map<String, ListState> accepted,
                                        Map<String, ListState> submitted) {
        JSONArray rows;
        try {
            rows = new JSONArray(prefs.getString("items", "[]"));
        } catch (JSONException ignored) {
            return;
        }
        boolean changed = false;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            MainActivity.Item item = decodeItem(row);
            TitleIdentity identity = item == null ? null : identityFor(item);
            if (row == null || identity == null) continue;
            ListState sent = submitted.get(identity.id);
            ListState server = accepted.get(identity.id);
            if (sent == null || server == null || !sent.present || !server.present
                    || row.optLong("time", 0L) != sent.updatedAtMs) continue;
            try {
                row.put("time", server.updatedAtMs);
                changed = true;
            } catch (JSONException ignored) {
                // Preserve the stored local timestamp.
            }
        }
        if (changed) prefs.edit().putString("items", rows.toString()).commit();
    }

    private Map<String, ListState> readLocalStates() {
        Map<String, ListState> result = new HashMap<>();
        SharedPreferences server1 = appContext.getSharedPreferences(SERVER1_PREFS, Context.MODE_PRIVATE);
        SharedPreferences server2 = appContext.getSharedPreferences(SERVER2_PREFS, Context.MODE_PRIVATE);
        readActiveItems(server1.getString("items", "[]"), result);
        readActiveItems(server2.getString("items", "[]"), result);

        JSONObject tombstones = readTombstones(appContext.getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE));
        Iterator<String> keys = tombstones.keys();
        while (keys.hasNext()) {
            String id = keys.next();
            JSONObject row = tombstones.optJSONObject(id);
            MainActivity.Item item = decodeItem(row);
            TitleIdentity identity = item == null ? null : identityFor(item);
            long updatedAt = row == null ? 0L : row.optLong("time", 0L);
            if (identity == null || !id.equals(identity.id) || updatedAt <= 0) continue;
            putNewest(result, new ListState(id, false, updatedAt, item));
        }
        return result;
    }

    private void readActiveItems(String encoded, Map<String, ListState> result) {
        try {
            JSONArray rows = new JSONArray(encoded);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                MainActivity.Item item = decodeItem(row);
                TitleIdentity identity = item == null ? null : identityFor(item);
                if (identity == null) continue;
                long updatedAt = row == null ? 0L : row.optLong("time", 0L);
                // Legacy on-device entries may not have a timestamp; treat their first
                // explicit sync as a local change rather than silently discarding them.
                if (updatedAt <= 0) updatedAt = System.currentTimeMillis();
                item.time = updatedAt;
                putNewest(result, new ListState(identity.id, true, updatedAt, item));
            }
        } catch (JSONException ignored) {
            // A malformed cloud-sync representation must not clear local preferences.
        }
    }

    private Map<String, ListState> parseRemoteRows(JSONArray rows) {
        Map<String, ListState> result = new HashMap<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            JSONObject title = relatedTitle(row.opt("titles"));
            MainActivity.Item item = itemFromTitle(title);
            TitleIdentity identity = item == null ? null : identityFor(item);
            String titleId = row.optString("title_id", "");
            long updatedAt = parseTimestamp(row.optString("client_updated_at", ""));
            if (identity == null || !identity.id.equals(titleId) || updatedAt <= 0) continue;
            item.time = updatedAt;
            putNewest(result, new ListState(titleId, row.optBoolean("is_present", false), updatedAt, item));
        }
        return result;
    }

    private void writeLocalStates(Map<String, ListState> states) throws IOException {
        ArrayList<MainActivity.Item> server1 = new ArrayList<>();
        ArrayList<MainActivity.Item> server2 = new ArrayList<>();
        JSONObject tombstones = new JSONObject();
        for (ListState state : states.values()) {
            if (state == null || state.item == null) continue;
            if (state.present) {
                state.item.time = state.updatedAtMs;
                if (MovyApi.isMovy(state.item.url)) server2.add(state.item);
                else server1.add(state.item);
            } else {
                try {
                    tombstones.put(state.titleId, encodeItem(state.item, state.updatedAtMs));
                } catch (JSONException ignored) {
                    // Do not make a failed tombstone serialization destructive to local state.
                }
            }
        }
        Comparator<MainActivity.Item> newestFirst = (a, b) -> Long.compare(b.time, a.time);
        Collections.sort(server1, newestFirst);
        Collections.sort(server2, newestFirst);
        if (!saveItems(appContext.getSharedPreferences(SERVER1_PREFS, Context.MODE_PRIVATE), server1)
                || !saveItems(appContext.getSharedPreferences(SERVER2_PREFS, Context.MODE_PRIVATE), server2)) {
            throw new IOException("Could not save the merged My List on this device; no cloud write was attempted.");
        }
        boolean saved = appContext.getSharedPreferences(SYNC_PREFS, Context.MODE_PRIVATE).edit()
                .putString(TOMBSTONES, tombstones.toString()).commit();
        if (!saved) throw new IOException("Could not save My List removal history on this device; no cloud write was attempted.");
    }

    private static boolean saveItems(SharedPreferences prefs, ArrayList<MainActivity.Item> items) {
        JSONArray rows = new JSONArray();
        for (MainActivity.Item item : items) {
            try {
                rows.put(encodeItem(item, item.time));
            } catch (JSONException ignored) {
                // Keep all other valid local rows.
            }
        }
        return prefs.edit().putString("items", rows.toString()).commit();
    }

    static JSONObject titlePayload(String userId, MainActivity.Item item) {
        TitleIdentity identity = identityFor(item);
        if (identity == null) return null;
        try {
            JSONObject metadata = new JSONObject();
            metadata.put("catalog_path", identity.path);
            if (!isEmpty(item.year)) metadata.put("year", item.year.length() > 16 ? item.year.substring(0, 16) : item.year);
            JSONObject row = new JSONObject();
            row.put("user_id", userId);
            row.put("id", identity.id);
            row.put("source", identity.source);
            row.put("title", item.title.trim());
            row.put("poster_url", safePosterUrl(item.img) ? item.img : JSONObject.NULL);
            row.put("metadata", metadata);
            return row;
        } catch (JSONException ignored) {
            return null;
        }
    }

    private static JSONObject listPayload(String userId, ListState state) {
        if (state == null || state.item == null || state.updatedAtMs <= 0) return null;
        try {
            JSONObject row = new JSONObject();
            row.put("user_id", userId);
            row.put("title_id", state.titleId);
            row.put("is_present", state.present);
            row.put("client_updated_at", formatTimestamp(state.updatedAtMs));
            return row;
        } catch (JSONException ignored) {
            return null;
        }
    }

    static JSONArray toJsonArray(ArrayList<JSONObject> rows) {
        JSONArray array = new JSONArray();
        for (JSONObject row : rows) array.put(row);
        return array;
    }

    static MainActivity.Item itemFromTitle(JSONObject title) {
        if (title == null) return null;
        String source = title.optString("source", "");
        JSONObject metadata = title.optJSONObject("metadata");
        String path = metadata == null ? "" : metadata.optString("catalog_path", "");
        String url = catalogUrl(source, path);
        String name = title.optString("title", "");
        if (url == null || isEmpty(name) || name.trim().length() > 250) return null;
        String poster = title.optString("poster_url", "");
        if (!safePosterUrl(poster)) poster = "";
        String year = metadata == null ? "" : metadata.optString("year", "");
        if (year.length() > 16) year = year.substring(0, 16);
        return new MainActivity.Item(name.trim(), url, poster, year);
    }

    static JSONObject relatedTitle(Object value) {
        if (value instanceof JSONObject) return (JSONObject) value;
        if (value instanceof JSONArray) return ((JSONArray) value).optJSONObject(0);
        return null;
    }

    private static Map<String, ListState> parseRemoteRowsForTest(JSONArray rows) {
        // Kept as a small seam for deterministic parsing tests without network access.
        Map<String, ListState> parsed = new HashMap<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            MainActivity.Item item = itemFromTitle(relatedTitle(row.opt("titles")));
            TitleIdentity identity = item == null ? null : identityFor(item);
            String id = row.optString("title_id", "");
            long time = parseTimestamp(row.optString("client_updated_at", ""));
            if (identity != null && identity.id.equals(id) && time > 0) {
                putNewest(parsed, new ListState(id, row.optBoolean("is_present", false), time, item));
            }
        }
        return parsed;
    }

    static TitleIdentity identityFor(MainActivity.Item item) {
        if (item == null || isEmpty(item.title) || item.title.trim().length() > 250) return null;
        String raw = item.url;
        if (isEmpty(raw)) return null;
        boolean server2 = MovyApi.isMovy(raw);
        String source = server2 ? "Server 2" : "Server 1";
        Uri uri;
        try {
            uri = Uri.parse(raw.startsWith("/") ? (server2 ? "https://www.movy.sx" : "https://play4u.org") + raw : raw);
        } catch (Exception ignored) {
            return null;
        }
        if (!"https".equalsIgnoreCase(uri.getScheme()) || hasUserInfo(uri) || uri.getQuery() != null || uri.getFragment() != null) return null;
        String host = uri.getHost();
        if (host == null) return null;
        String path = uri.getPath();
        if (path == null || !isValidCatalogPath(source, host, path)) return null;
        String id = (server2 ? "s2-" : "s1-") + sha256(path);
        return new TitleIdentity(id, source, path);
    }

    static String catalogUrl(String source, String path) {
        if (isEmpty(path) || !path.startsWith("/") || path.length() > 512 || path.contains("?") || path.contains("#")) return null;
        if ("Server 1".equals(source) && isValidCatalogPath(source, "play4u.org", path)) return "https://play4u.org" + path;
        if ("Server 2".equals(source) && isValidCatalogPath(source, "www.movy.sx", path)) return "https://www.movy.sx" + path;
        return null;
    }

    private static boolean isValidCatalogPath(String source, String host, String path) {
        if (path == null || path.length() < 3 || path.length() > 512) return false;
        if ("Server 2".equals(source)) {
            if (!"www.movy.sx".equalsIgnoreCase(host)) return false;
            return path.matches("^/(movie|tv)/[0-9]{1,12}$");
        }
        if (!"play4u.org".equalsIgnoreCase(host) && !"www.play4u.org".equalsIgnoreCase(host)) return false;
        return path.matches("^/(watch|series)/[A-Za-z0-9._~-]{1,200}$");
    }

    private static boolean hasUserInfo(Uri uri) {
        String authority = uri == null ? null : uri.getEncodedAuthority();
        return authority != null && authority.indexOf('@') >= 0;
    }

    private static boolean safePosterUrl(String poster) {
        if (isEmpty(poster) || poster.length() > 2048) return false;
        try {
            Uri uri = Uri.parse(poster);
            String path = uri.getPath();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || hasUserInfo(uri)
                    || uri.getQuery() != null || uri.getFragment() != null || path == null) return false;
            String lowerPath = path.toLowerCase(Locale.US);
            return !lowerPath.matches(".*\\.(m3u8|m3u|mpd|mp4|m4v|mkv|webm|ts|mov|mp3|m4a)$")
                    && !lowerPath.contains("/stream/") && !lowerPath.contains("/playlist/");
        } catch (Exception ignored) {
            return false;
        }
    }

    static String formatTimestamp(long timeMs) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(timeMs));
    }

    static long parseTimestamp(String value) {
        if (isEmpty(value)) return 0L;
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(
                "^(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(?:\\.(\\d+))?(Z|[+-]\\d{2}:?\\d{2})$")
                .matcher(value.trim());
        if (!matcher.matches()) return 0L;
        try {
            SimpleDateFormat secondsFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            secondsFormat.setLenient(false);
            secondsFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            long epoch = secondsFormat.parse(matcher.group(1)).getTime();
            String fraction = matcher.group(2);
            if (fraction != null) {
                String millis = (fraction + "000").substring(0, 3);
                epoch += Integer.parseInt(millis);
            }
            String zone = matcher.group(3);
            if (!"Z".equals(zone)) {
                boolean positive = zone.charAt(0) == '+';
                String digits = zone.substring(1).replace(":", "");
                int hours = Integer.parseInt(digits.substring(0, 2));
                int minutes = Integer.parseInt(digits.substring(2, 4));
                long offset = (hours * 60L + minutes) * 60_000L;
                epoch += positive ? -offset : offset;
            }
            return epoch;
        } catch (ParseException | RuntimeException ignored) {
            return 0L;
        }
    }

    static boolean localWinsForTest(long localTime, boolean localPresent, long remoteTime, boolean remotePresent) {
        if (localTime != remoteTime) return localTime > remoteTime;
        return !localPresent && remotePresent;
    }

    private static boolean localWins(ListState local, ListState remote) {
        return localWinsForTest(local.updatedAtMs, local.present, remote.updatedAtMs, remote.present);
    }

    private static void putNewest(Map<String, ListState> rows, ListState value) {
        ListState old = rows.get(value.titleId);
        if (old == null || (value.updatedAtMs > old.updatedAtMs)
                || (value.updatedAtMs == old.updatedAtMs && !value.present && old.present)) {
            rows.put(value.titleId, value);
        }
    }

    private static JSONObject readTombstones(SharedPreferences prefs) {
        try {
            return new JSONObject(prefs.getString(TOMBSTONES, "{}"));
        } catch (Exception ignored) {
            return new JSONObject();
        }
    }

    private static JSONObject encodeItem(MainActivity.Item item, long time) throws JSONException {
        JSONObject row = new JSONObject();
        row.put("title", item.title);
        row.put("url", item.url);
        row.put("img", item.img == null ? "" : item.img);
        row.put("year", item.year == null ? "" : item.year);
        row.put("time", time);
        return row;
    }

    private static MainActivity.Item decodeItem(JSONObject row) {
        if (row == null) return null;
        MainActivity.Item item = new MainActivity.Item(row.optString("title", ""), row.optString("url", ""),
                row.optString("img", ""), row.optString("year", ""));
        item.time = row.optLong("time", 0L);
        return item;
    }

    private static String sha256(String value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder(digest.length * 2);
            for (byte b : digest) hex.append(String.format(Locale.US, "%02x", b & 0xff));
            return hex.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is unavailable", impossible);
        }
    }

    private static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static final class ListState {
        final String titleId;
        final boolean present;
        final long updatedAtMs;
        final MainActivity.Item item;

        ListState(String titleId, boolean present, long updatedAtMs, MainActivity.Item item) {
            this.titleId = titleId;
            this.present = present;
            this.updatedAtMs = updatedAtMs;
            this.item = item;
        }
    }

    static final class TitleIdentity {
        final String id;
        final String source;
        final String path;

        TitleIdentity(String id, String source, String path) {
            this.id = id;
            this.source = source;
            this.path = path;
        }
    }

    public static final class SyncResult {
        public final int savedCount;
        public final int removedCount;
        public final int localRecordsUploaded;

        SyncResult(int savedCount, int removedCount, int localRecordsUploaded) {
            this.savedCount = savedCount;
            this.removedCount = removedCount;
            this.localRecordsUploaded = localRecordsUploaded;
        }
    }
}
