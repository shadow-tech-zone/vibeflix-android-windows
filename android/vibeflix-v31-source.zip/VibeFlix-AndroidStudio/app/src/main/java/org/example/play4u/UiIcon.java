package org.example.play4u;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;

/** Original 24-unit line icons, created for Vibeflix. Not Netflix assets. */
final class UiIcon extends Drawable {
    private final String kind; private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color,alpha=255; private final int size; private ColorFilter filter;
    UiIcon(String kind,int color,int size){this.kind=kind;this.color=color;this.size=size;setBounds(0,0,size,size);}
    @Override public void draw(Canvas c){int save=c.save();android.graphics.Rect b=getBounds();c.translate(b.left,b.top);c.scale(b.width()/24f,b.height()/24f);p.setColor(color);p.setAlpha(alpha);p.setColorFilter(filter);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.9f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path path=new Path();switch(kind){
      case "play":p.setStyle(Paint.Style.FILL);path.moveTo(6,3);path.lineTo(20,12);path.lineTo(6,21);path.close();c.drawPath(path,p);break;
      case "add":c.drawLine(12,4,12,20,p);c.drawLine(4,12,20,12,p);break;
      case "check":path.moveTo(4,12);path.lineTo(9,17);path.lineTo(20,6);c.drawPath(path,p);break;
      case "search":c.drawCircle(10.2f,10.2f,6.1f,p);c.drawLine(15,15,20.5f,20.5f,p);break;
      case "back":path.moveTo(15,4);path.lineTo(7,12);path.lineTo(15,20);c.drawPath(path,p);break;
      case "close":c.drawLine(5,5,19,19,p);c.drawLine(19,5,5,19,p);break;
      case "history":c.drawArc(3,3,21,21,-90,310,false,p);path.moveTo(3,4);path.lineTo(3,9);path.lineTo(8,9);c.drawPath(path,p);c.drawLine(12,7,12,12,p);c.drawLine(12,12,16,14,p);break;
      case "episodes":c.drawRoundRect(3,4,21,20,2,2,p);c.drawLine(7,9,17,9,p);c.drawLine(7,13,17,13,p);c.drawLine(7,17,13,17,p);break;
      case "more":p.setStyle(Paint.Style.FILL);c.drawCircle(12,5,1.5f,p);c.drawCircle(12,12,1.5f,p);c.drawCircle(12,19,1.5f,p);break;
      case "settings":for(int i=0;i<8;i++){double a=i*Math.PI/4;float x=(float)Math.cos(a),y=(float)Math.sin(a);c.drawLine(12+8*x,12+8*y,12+10*x,12+10*y,p);}c.drawCircle(12,12,6.3f,p);c.drawCircle(12,12,2.2f,p);break;
      default:break;
    }c.restoreToCount(save);}
    @Override public int getIntrinsicWidth(){return size;}
    @Override public int getIntrinsicHeight(){return size;}
    @Override public void setAlpha(int a){alpha=a;invalidateSelf();}
    @Override public void setColorFilter(ColorFilter f){filter=f;invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
