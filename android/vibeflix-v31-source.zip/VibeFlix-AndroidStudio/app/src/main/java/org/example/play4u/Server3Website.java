package org.example.play4u;

import java.net.URI;
import java.net.URLEncoder;
import java.io.IOException;
import org.jsoup.Connection;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

/** Parser for the observed Server 3 pages. No playback URLs are persisted. */
final class Server3Website {
    static final String ROOT = "https://newhdmovie2.fast";
    private static final String SITE_HOST = "newhdmovie2.fast";
    private static final String PLAYER_HOST = "hdm2.biz";

    static final class Title {
        final String name, url, poster, year;
        Title(String name, String url, String poster, String year) {
            this.name = name; this.url = url; this.poster = poster; this.year = year;
        }
    }

    static final class Source {
        final String label, embedUrl;
        Source(String label, String embedUrl) { this.label = label; this.embedUrl = embedUrl; }
    }

    static final class Details {
        final String rating;
        final List<String> genres;
        Details(String rating, List<String> genres) { this.rating = rating; this.genres = genres; }
    }

    /** Read only visible details, not the promotional SEO description or download links. */
    static Details parseDetails(String html) {
        Document doc = Jsoup.parse(html, ROOT + "/");
        Element value = doc.selectFirst(".sheader .srating .promedio");
        String rating = value == null ? "" : value.text().trim();
        if (!rating.matches("(?:[0-9](?:\\.[0-9])?|10(?:\\.0)?)")) rating = "";
        List<String> genres = new ArrayList<>();
        for (Element genre : doc.select(".sheader .sgeneros a")) {
            String name = genre.text().trim();
            if (!name.isEmpty() && name.length() <= 70 && !genres.contains(name)) genres.add(name);
        }
        return new Details(rating, genres);
    }

    /** Only accepts HTTPS URLs on an exact host. This also rejects credentials and nonstandard ports. */
    static String safeUrl(String raw, String base, String expectedHost) {
        try {
            URI u = new URI(base).resolve(raw.trim()).normalize();
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost() == null
                    || !expectedHost.equalsIgnoreCase(u.getHost()) || u.getRawUserInfo() != null
                    || (u.getPort() != -1 && u.getPort() != 443)) return "";
            return u.toASCIIString();
        } catch (Exception ignored) { return ""; }
    }

    static boolean isTitleUrl(String raw) {
        String safe = safeUrl(raw, ROOT + "/", SITE_HOST);
        if (safe.isEmpty()) return false;
        try {
            URI u = new URI(safe);
            String path = u.getPath();
            if (u.getRawQuery() != null || u.getRawFragment() != null || path == null
                    || !path.matches("/movie/[^/\\\\]{1,240}/?")) return false;
            String slug = path.substring("/movie/".length());
            if (slug.endsWith("/")) slug = slug.substring(0, slug.length() - 1);
            return !".".equals(slug) && !"..".equals(slug);
        } catch (Exception ignored) { return false; }
    }

    static List<Title> parseCatalog(String html) {
        Document doc = Jsoup.parse(html, ROOT + "/");
        LinkedHashMap<String, Title> found = new LinkedHashMap<>();
        for (Element card : doc.select("article.item, .result-item")) {
            Element link = card.selectFirst(".data h3 a[href], .details .title a[href], h3 a[href]");
            Element image = card.selectFirst(".poster img, .image img");
            if (link == null || image == null) continue;
            String url = safeUrl(link.attr("href"), ROOT + "/", SITE_HOST);
            String title = link.text().trim();
            if (!isTitleUrl(url) || title.isEmpty()) continue;
            String poster = image.hasAttr("data-src") ? image.attr("data-src") : image.attr("src");
            try {
                URI posterUrl = new URI(ROOT + "/").resolve(poster.trim());
                if (!"https".equalsIgnoreCase(posterUrl.getScheme()) || posterUrl.getHost() == null
                        || posterUrl.getRawUserInfo() != null) poster = "";
                else poster = posterUrl.toASCIIString();
            } catch (Exception ignored) { poster = ""; }
            Element yearEl = card.selectFirst(".data span, .details .year");
            String year = yearEl == null ? "" : yearEl.text().trim();
            if (!year.matches("[0-9]{4}")) year = "";
            if (!found.containsKey(url)) found.put(url, new Title(title, url, poster, year));
        }
        return new ArrayList<>(found.values());
    }

    /** The first-party embed is supported; unknown third-party hosts are not fetched. */
    static List<Source> parseSources(String html) {
        Document doc = Jsoup.parse(html, ROOT + "/");
        LinkedHashMap<String, Source> found = new LinkedHashMap<>();
        for (Element option : doc.select("[data-source-embed]")) {
            Document embed = Jsoup.parseBodyFragment(option.attr("data-source-embed"), ROOT + "/");
            Element frame = embed.selectFirst("iframe[src]");
            if (frame == null) continue;
            String url = safeUrl(frame.attr("src"), ROOT + "/", SITE_HOST);
            if (url.isEmpty()) continue;
            try {
                URI u = new URI(url);
                if (!u.getPath().matches("/hdm2-player/[A-Za-z0-9_-]{1,100}")
                        || u.getRawQuery() != null || u.getRawFragment() != null) continue;
            } catch (Exception ignored) { continue; }
            Element label = option.selectFirst(".title");
            String name = label == null ? "Stream" : label.text().trim();
            if (name.isEmpty()) name = "Stream";
            if (!found.containsKey(url)) found.put(url, new Source(name, url));
        }
        return new ArrayList<>(found.values());
    }

    /** Episode numbers are used only when the provider gives an unambiguous EP label. */
    static int episodeNumber(String label) {
        if (label == null) return 0;
        java.util.regex.Matcher match = java.util.regex.Pattern.compile("(?i)(?:^|\\s)EP(?:ISODE)?\\s*0*([1-9][0-9]{0,3})\\s*$").matcher(label);
        if (!match.find()) return 0;
        try { return Integer.parseInt(match.group(1)); } catch (Exception ignored) { return 0; }
    }

    static List<Source> episodeSources(List<Source> sources) {
        List<Source> episodes = new ArrayList<>();
        for (Source source : sources) if (episodeNumber(source.label) > 0) episodes.add(source);
        java.util.Collections.sort(episodes, (a, b) -> Integer.compare(episodeNumber(a.label), episodeNumber(b.label)));
        return episodes;
    }

    static String nextEpisode(String title, String current, List<Source> sources) {
        if (!isTitleUrl(title) || !title.equals(titleFromPlayback(current))) return "";
        Source active = null;
        for (Source source : sources) if (current.equals(playbackPath(title, source))) { active = source; break; }
        if (active == null) return "";
        int currentNumber = episodeNumber(active.label);
        if (currentNumber == 0) return "";
        String prefix = active.label.replaceFirst("(?i)(?:^|\\s)EP(?:ISODE)?\\s*0*[1-9][0-9]{0,3}\\s*$", "").trim();
        Source chosen = null; int next = Integer.MAX_VALUE;
        for (Source source : sources) {
            int number = episodeNumber(source.label);
            if (number <= currentNumber) continue;
            String candidatePrefix = source.label.replaceFirst("(?i)(?:^|\\s)EP(?:ISODE)?\\s*0*[1-9][0-9]{0,3}\\s*$", "").trim();
            String chosenPrefix = chosen == null ? "" : chosen.label.replaceFirst("(?i)(?:^|\\s)EP(?:ISODE)?\\s*0*[1-9][0-9]{0,3}\\s*$", "").trim();
            if (number < next || (number == next && candidatePrefix.equalsIgnoreCase(prefix) && !chosenPrefix.equalsIgnoreCase(prefix))) {
                next = number; chosen = source;
            }
        }
        return chosen == null ? "" : playbackPath(title, chosen);
    }

    /** Extracts a fresh runtime-only playlist from the observed player document. */
    static String parsePlaylist(String html, String playerUrl) {
        String safePlayer = safeUrl(playerUrl, "https://" + PLAYER_HOST + "/", PLAYER_HOST);
        if (safePlayer.isEmpty()) return "";
        Document doc = Jsoup.parse(html, safePlayer);
        Element loader = doc.selectFirst("script#player-loader[data-stream-url]");
        if (loader == null) return "";
        String stream = safeUrl(loader.attr("data-stream-url"), safePlayer, PLAYER_HOST);
        if (stream.isEmpty()) return "";
        try {
            URI uri = new URI(stream);
            if (!uri.getPath().startsWith("/playlist/") || uri.getRawFragment() != null) return "";
        } catch (Exception ignored) { return ""; }
        return stream;
    }

    static String titleFromPlayback(String raw) {
        String safe = safeUrl(raw, ROOT + "/", SITE_HOST);
        if (safe.isEmpty()) return "";
        try {
            URI u = new URI(safe);
            if (u.getRawFragment() != null) return "";
            String q = u.getRawQuery();
            if (q != null && !q.matches("s3source=[A-Za-z0-9_-]{1,100}")) return "";
            String title = new URI("https", null, SITE_HOST, -1, u.getPath(), null, null).toASCIIString();
            return isTitleUrl(title) ? title : "";
        } catch (Exception ignored) { return ""; }
    }

    static String playbackPath(String titleUrl, Source source) {
        if (!isTitleUrl(titleUrl) || source == null) return "";
        String embed = safeUrl(source.embedUrl, ROOT + "/", SITE_HOST);
        if (embed.isEmpty()) return "";
        try {
            URI uri = new URI(embed);
            if (uri.getRawQuery() != null || uri.getRawFragment() != null) return "";
            String path = uri.getPath();
            if (!path.matches("/hdm2-player/[A-Za-z0-9_-]{1,100}")) return "";
            return titleUrl + "?s3source=" + path.substring("/hdm2-player/".length());
        } catch (Exception ignored) { return ""; }
    }

    static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36";

    static String catalogUrl(String query, int page) throws Exception {
        if (page < 1 || page > 1000) throw new IOException("Invalid page");
        String path = page == 1 ? "/" : "/page/" + page + "/";
        return ROOT + path + (query.isEmpty() ? "" : "?s=" + URLEncoder.encode(query, "UTF-8"));
    }

    static LinkedHashMap<String, String> parseGenres(String html) {
        LinkedHashMap<String, String> genres = new LinkedHashMap<>();
        Document doc = Jsoup.parse(html, ROOT + "/");
        for (Element link : doc.select("a[href]")) {
            String url = safeUrl(link.attr("href"), ROOT + "/", SITE_HOST);
            if (url.isEmpty()) continue;
            try {
                URI uri = new URI(url);
                if (uri.getRawQuery() != null || uri.getRawFragment() != null
                        || !uri.getPath().matches("/genre/[a-z0-9-]{1,100}/?")) continue;
                String slug = uri.getPath().substring("/genre/".length());
                if (slug.endsWith("/")) slug = slug.substring(0, slug.length() - 1);
                String name = link.text().trim();
                if (name.isEmpty() || name.length() > 70 || genres.containsKey(slug)) continue;
                genres.put(slug, name);
            } catch (Exception ignored) { }
        }
        return genres;
    }

    static String genreUrl(String slug, int page) throws IOException {
        if (slug == null || !slug.matches("[a-z0-9-]{1,100}") || page < 1 || page > 1000)
            throw new IOException("Invalid Server 3 category");
        return ROOT + "/genre/" + slug + "/" + (page == 1 ? "" : "page/" + page + "/");
    }

    interface Fetcher { Response get(String url, String referrer) throws Exception; }
    static final class Response {
        final int status; final String location, body;
        Response(int status, String location, String body) {
            this.status = status; this.location = location; this.body = body;
        }
    }

    static Response fetch(String url, String referrer) throws Exception {
        Connection.Response response = Jsoup.connect(url).userAgent(USER_AGENT).referrer(referrer)
                .followRedirects(false).ignoreHttpErrors(true).timeout(20000).execute();
        return new Response(response.statusCode(), response.header("Location"), response.body());
    }

    static String getSite(String url) throws Exception { return getSite(url, Server3Website::fetch); }
    static String getSite(String url, Fetcher fetcher) throws Exception {
        String safe = safeUrl(url, ROOT + "/", SITE_HOST);
        if (safe.isEmpty()) throw new IOException("Invalid Server 3 address");
        Response response = fetcher.get(safe, ROOT + "/");
        if (response.status != 200) throw new IOException("Server 3 is unavailable");
        return response.body;
    }

    static boolean hasNextPage(String html) {
        Document doc = Jsoup.parse(html, ROOT + "/");
        for (Element link : doc.select("a.next[href], a[rel~=next][href], .pagination a[href]")) {
            if (!(link.hasClass("next") || "next".equalsIgnoreCase(link.attr("rel"))
                    || link.text().trim().contains("Next") || link.text().trim().contains("»"))) continue;
            if (!safeUrl(link.attr("href"), ROOT + "/", SITE_HOST).isEmpty()) return true;
        }
        return false;
    }

    static final class Resolution {
        final String playbackPath, playlistUrl;
        Resolution(String playbackPath, String playlistUrl) { this.playbackPath = playbackPath; this.playlistUrl = playlistUrl; }
    }

    /** Follows only the observed first-party embed redirect to the known player host. */
    static String resolvePlaylist(String playbackUrl) throws Exception { return resolve(playbackUrl, Server3Website::fetch).playlistUrl; }
    static String resolvePlaylist(String playbackUrl, Fetcher fetcher) throws Exception { return resolve(playbackUrl, fetcher).playlistUrl; }
    static Resolution resolve(String playbackUrl) throws Exception { return resolve(playbackUrl, Server3Website::fetch); }
    static Resolution resolve(String playbackUrl, Fetcher fetcher) throws Exception {
        String title = titleFromPlayback(playbackUrl);
        if (title.isEmpty()) throw new IOException("Invalid Server 3 title");
        URI input = new URI(playbackUrl);
        String query = input.getRawQuery();
        List<Source> sources = parseSources(getSite(title, fetcher));
        Source selected = null;
        if (query == null && !sources.isEmpty()) selected = sources.get(0);
        else for (Source source : sources) {
            if (playbackUrl.equals(playbackPath(title, source))) { selected = source; break; }
        }
        if (selected == null) throw new IOException("Server 3 source unavailable");
        String embed = selected.embedUrl;
        Response redirect = fetcher.get(embed, title);
        if (redirect.status < 300 || redirect.status >= 400)
            throw new IOException("Server 3 player unavailable");
        String playerUrl = safeUrl(redirect.location, embed, PLAYER_HOST);
        if (playerUrl.isEmpty()) throw new IOException("Unsupported Server 3 player");
        Response player = fetcher.get(playerUrl, embed);
        if (player.status != 200) throw new IOException("Server 3 player blocked or unavailable");
        String stream = parsePlaylist(player.body, playerUrl);
        if (stream.isEmpty()) throw new IOException("Server 3 playlist unavailable");
        String resolvedPath = playbackPath(title, selected);
        if (resolvedPath.isEmpty()) throw new IOException("Server 3 source unavailable");
        return new Resolution(resolvedPath, stream);
    }

    private Server3Website() {}
}
