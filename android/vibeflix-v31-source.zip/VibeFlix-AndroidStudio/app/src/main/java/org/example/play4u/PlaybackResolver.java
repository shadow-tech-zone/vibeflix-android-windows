package org.example.play4u;

import android.net.Uri;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/** Resolves the site's current public player bootstrap response; no DRM or login handling. */
final class PlaybackResolver {
    static String resolve(String html) throws Exception {
        Matcher payload=Pattern.compile("window\\.__PA_PLAY__\\s*=\\s*(\\{.*?\\})\\s*;",Pattern.DOTALL).matcher(html);
        if(!payload.find()) throw new IllegalStateException("Player data unavailable");
        JSONObject obj=new JSONObject(payload.group(1)); JSONArray streams=obj.optJSONArray("streams"); String source="";
        if(streams!=null) for(int i=0;i<streams.length();i++){JSONObject e=streams.optJSONObject(i);if(e!=null){source=e.optString("m3u8_url","");if(!source.isEmpty()&&!source.equals("null"))break;}}
        if(source.isEmpty()||source.equals("null")) throw new IllegalStateException("No stream is available");
        if(source.startsWith("pa!~")){
            Matcher keyMatch=Pattern.compile("window\\.__PA_SEAL_KEY__\\s*=\\s*[\"']([^\"']+)[\"']").matcher(html);
            if(!keyMatch.find()) throw new IllegalStateException("Stream format changed");
            byte[] key=keyMatch.group(1).getBytes(StandardCharsets.UTF_8); if(key.length==0)throw new IllegalStateException("Stream key missing");
            byte[] bytes=Base64.decode(source.substring(4),Base64.URL_SAFE | Base64.NO_WRAP);
            for(int i=0;i<bytes.length;i++)bytes[i]=(byte)(bytes[i]^key[i%key.length]);
            source=new String(bytes,StandardCharsets.UTF_8);
        }
        if(source.startsWith("/"))source="https://play4u.org"+source;
        Uri uri=Uri.parse(source);
        if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getHost()==null)throw new IllegalStateException("Unsupported stream address");
        return source;
    }
}
