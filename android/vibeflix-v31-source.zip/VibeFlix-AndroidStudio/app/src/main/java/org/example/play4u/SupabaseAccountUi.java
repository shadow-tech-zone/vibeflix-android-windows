package org.example.play4u;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.Executor;

/** Native sign-in-only UI. Account creation is disabled for this personal project. */
public final class SupabaseAccountUi {
    private SupabaseAccountUi() {}

    public static String buttonLabel(SupabaseAuthRepository auth) {
        if (!auth.isConfigured()) return "Cloud sync · Not configured in this build";
        return auth.hasSession() ? "Cloud account · Library sync available" : "Sign in for cloud sync";
    }

    public static void show(Activity activity, SupabaseAuthRepository auth, Executor executor, Runnable onChanged) {
        if (!auth.isConfigured()) {
            new AlertDialog.Builder(activity)
                    .setTitle("Cloud sync unavailable")
                    .setMessage("This build has no Supabase publishable key configured. Your on-device My List, History, Continue Watching, and resume data are unchanged.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        if (auth.hasSession()) {
            showSignedIn(activity, auth, executor, onChanged);
        } else {
            showSignIn(activity, auth, executor, onChanged);
        }
    }

    private static void showSignedIn(Activity activity, SupabaseAuthRepository auth, Executor executor, Runnable onChanged) {
        SupabaseSessionStore.Session session = auth.currentSession();
        boolean syncEnabled = session != null && SupabaseLibrarySync.isEnabledFor(activity, session.userId);
        String message = syncEnabled
                ? "Library sync is enabled for this account. My List, latest History, resume/progress, and Continue Watching visibility sync when you choose Sync. Turning sync off stops future syncs but does not delete the cloud copy. Local data stays available offline. Stream URLs and provider credentials are never uploaded."
                : "You are signed in. My List, latest History, resume/progress, and Continue Watching visibility stay on this device unless you explicitly enable library sync from My Vibeflix. Nothing is uploaded before opt-in. Local data stays available offline. Stream URLs and provider credentials are never uploaded.";
        AlertDialog.Builder builder = new AlertDialog.Builder(activity)
                .setTitle("Cloud account")
                .setMessage(message)
                .setNegativeButton("Close", null)
                .setPositiveButton("Sign out", (dialog, which) -> executor.execute(() -> {
                    try {
                        auth.signOut();
                    } catch (IOException ignored) {
                        // Local tokens are cleared before the remote logout request.
                    }
                    postIfAlive(activity, () -> {
                        Toast.makeText(activity, "Signed out on this device.", Toast.LENGTH_SHORT).show();
                        if (onChanged != null) onChanged.run();
                    });
                }));
        if (syncEnabled && session != null) {
            builder.setNeutralButton("Turn off sync", (dialog, which) -> {
                boolean disabled = SupabaseLibrarySync.disableFor(activity, session.userId);
                Toast.makeText(activity, disabled
                        ? "Library sync is off. Local and existing cloud data were kept."
                        : "Could not turn sync off. Please try again.", Toast.LENGTH_LONG).show();
                if (disabled && onChanged != null) onChanged.run();
            });
        }
        builder.show();
    }

    private static void showSignIn(Activity activity, SupabaseAuthRepository auth, Executor executor, Runnable onChanged) {
        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(activity, 24), dp(activity, 8), dp(activity, 24), dp(activity, 4));

        TextView note = new TextView(activity);
        note.setText("Account creation is disabled. Sign in with an account provisioned by the project owner. Library sync is optional and nothing is uploaded until you explicitly enable it. No stream URLs or provider credentials are uploaded.");
        note.setTextSize(14);
        note.setPadding(0, 0, 0, dp(activity, 12));
        panel.addView(note, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        EditText email = new EditText(activity);
        email.setSingleLine(true);
        email.setHint("Email address");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        panel.addView(email, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 52)));

        EditText password = new EditText(activity);
        password.setSingleLine(true);
        password.setHint("Password");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        panel.addView(password, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 52)));

        TextView error = new TextView(activity);
        error.setTextSize(13);
        error.setPadding(0, dp(activity, 8), 0, 0);
        error.setVisibility(View.GONE);
        panel.addView(error, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("Sign in to Vibeflix")
                .setView(panel)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Sign in", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            Button signIn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            signIn.setOnClickListener(view -> {
                String emailValue = email.getText().toString().trim();
                String passwordValue = password.getText().toString();
                if (emailValue.isEmpty() || passwordValue.isEmpty()) {
                    error.setText("Enter both email and password.");
                    error.setVisibility(View.VISIBLE);
                    return;
                }
                signIn.setEnabled(false);
                signIn.setText("Signing in…");
                error.setVisibility(View.GONE);
                password.setText("");
                executor.execute(() -> {
                    String failure = null;
                    try {
                        auth.signIn(emailValue, passwordValue);
                    } catch (IOException problem) {
                        failure = problem.getMessage();
                    }
                    String result = failure;
                    postIfAlive(activity, () -> {
                        if (dialog.isShowing()) {
                            if (result == null) {
                                dialog.dismiss();
                                Toast.makeText(activity, "Signed in. Nothing was uploaded. You can explicitly enable My List sync from My Vibeflix.", Toast.LENGTH_LONG).show();
                                if (onChanged != null) onChanged.run();
                            } else {
                                error.setText(result);
                                error.setVisibility(View.VISIBLE);
                                signIn.setEnabled(true);
                                signIn.setText("Sign in");
                            }
                        }
                    });
                });
            });
        });
        dialog.show();
    }

    private static void postIfAlive(Activity activity, Runnable action) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (!activity.isFinishing() && !activity.isDestroyed()) action.run();
        });
    }

    private static int dp(Context context, float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }
}
