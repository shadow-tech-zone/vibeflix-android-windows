package org.example.play4u;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.json.JSONArray;
import org.json.JSONObject;

/** Limited public website selection used only when the provider catalogue API fails. */
final class Server2WebsiteCatalog {
 static ArrayList<MainActivity.Item> load(String type)throws Exception {
  if(!type.isEmpty()&&!type.equals("movie")&&!type.equals("series"))throw new IOException("No website selection for this filter");
  String path=type.isEmpty()?"/":type.equals("series")?"/browse/tv":"/browse/movie";
  return parse(MovyApi.get(MovyApi.ROOT+path),type);
 }
 static ArrayList<MainActivity.Item> parse(String html,String type)throws Exception {
  Element el=Jsoup.parse(html).selectFirst("script#__NEXT_DATA__");if(el==null)throw new IOException("Website data unavailable");
  JSONObject props=new JSONObject(el.html()).optJSONObject("props");JSONObject page=props==null?null:props.optJSONObject("pageProps");if(page==null)throw new IOException("Website data invalid");
  ArrayList<MainActivity.Item> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  if(type.isEmpty()) {for(String name:new String[]{"trendingSections","defaultSections","streamingSections"}){JSONArray sections=page.optJSONArray(name);if(sections!=null)for(int i=0;i<sections.length();i++){JSONObject o=sections.optJSONObject(i);if(o!=null)add(out,seen,o.optJSONArray("movies"));}}add(out,seen,page.optJSONArray("upcomingTv"));add(out,seen,page.optJSONArray("recent4k"));}
  else if(type.equals("movie")||type.equals("series"))add(out,seen,page.optJSONArray("initialGrid"));else throw new IOException("Unsupported filter");
  if(out.isEmpty())throw new IOException("No website titles available");return out;
 }
 static void add(ArrayList<MainActivity.Item> out,HashSet<String> seen,JSONArray rows){if(rows==null)return;for(int i=0;i<rows.length();i++){JSONObject o=rows.optJSONObject(i);if(o==null)continue;String slug=o.optString("slug",""),title=o.optString("title","").trim(),img=o.optString("poster","");if(!slug.matches("/(movie|tv)/[0-9]{1,12}")||title.isEmpty()||!img.startsWith("/img/")||img.startsWith("//")||!seen.add(slug))continue;String date=o.optString("release_date","");out.add(new MainActivity.Item(title,MovyApi.ROOT+slug,MovyApi.ROOT+img,date.length()>=4?date.substring(0,4):""));}}
 static boolean eligible(String type,String query,int page){return query.isEmpty()&&page==1&&(type.isEmpty()||type.equals("movie")||type.equals("series"));}
 static String reason(Exception e){if(e instanceof org.jsoup.HttpStatusException)return "HTTP "+((org.jsoup.HttpStatusException)e).getStatusCode();if(e instanceof java.net.SocketTimeoutException)return "connection timed out";if(e instanceof java.net.UnknownHostException)return "DNS lookup failed";if(e instanceof javax.net.ssl.SSLException)return "secure connection failed";if(e instanceof org.json.JSONException)return "invalid data response";if(e instanceof java.io.IOException)return "network connection failed";return "unexpected response";}
}
