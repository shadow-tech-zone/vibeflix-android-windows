package org.example.play4u;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Stores Supabase session tokens encrypted with a non-exportable Android Keystore key. */
public final class SupabaseSessionStore {
    private static final String PREFERENCES = "vibeflix_supabase_session";
    private static final String SESSION_KEY = "encrypted_session_v1";
    private static final String KEY_ALIAS = "org.example.play4u.supabase.session.v1";
    private static final byte[] AAD = "Vibeflix Supabase session v1".getBytes(StandardCharsets.UTF_8);
    private static final int GCM_TAG_BITS = 128;

    private final SharedPreferences preferences;

    public SupabaseSessionStore(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }

    public synchronized void save(Session session) throws GeneralSecurityException, JSONException {
        if (session == null || isEmpty(session.accessToken) || isEmpty(session.refreshToken) || isEmpty(session.userId)) {
            throw new IllegalArgumentException("A complete authenticated session is required");
        }
        JSONObject json = new JSONObject();
        json.put("access_token", session.accessToken);
        json.put("refresh_token", session.refreshToken);
        json.put("user_id", session.userId);
        json.put("expires_at_ms", session.expiresAtMs);
        byte[] encrypted = encrypt(json.toString().getBytes(StandardCharsets.UTF_8));
        String encoded = Base64.encodeToString(encrypted, Base64.NO_WRAP);
        if (!preferences.edit().putString(SESSION_KEY, encoded).commit()) {
            throw new GeneralSecurityException("Could not persist the encrypted session");
        }
    }

    /** Returns null if no valid saved session is available. Corrupt data is discarded. */
    public synchronized Session load() {
        String encoded = preferences.getString(SESSION_KEY, null);
        if (isEmpty(encoded)) return null;
        try {
            byte[] plaintext = decrypt(Base64.decode(encoded, Base64.NO_WRAP));
            JSONObject json = new JSONObject(new String(plaintext, StandardCharsets.UTF_8));
            Session session = new Session(
                    json.getString("access_token"),
                    json.getString("refresh_token"),
                    json.getString("user_id"),
                    json.getLong("expires_at_ms"));
            if (isEmpty(session.accessToken) || isEmpty(session.refreshToken) || isEmpty(session.userId)) {
                clear();
                return null;
            }
            return session;
        } catch (Exception ignored) {
            clear();
            return null;
        }
    }

    public synchronized void clear() {
        preferences.edit().remove(SESSION_KEY).apply();
    }

    private byte[] encrypt(byte[] plaintext) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        cipher.updateAAD(AAD);
        byte[] iv = cipher.getIV();
        byte[] ciphertext = cipher.doFinal(plaintext);
        byte[] result = new byte[1 + iv.length + ciphertext.length];
        result[0] = (byte) iv.length;
        System.arraycopy(iv, 0, result, 1, iv.length);
        System.arraycopy(ciphertext, 0, result, 1 + iv.length, ciphertext.length);
        Arrays.fill(plaintext, (byte) 0);
        return result;
    }

    private byte[] decrypt(byte[] value) throws GeneralSecurityException {
        if (value == null || value.length < 1 + 12 + 16) {
            throw new GeneralSecurityException("Invalid encrypted session format");
        }
        int ivLength = value[0] & 0xff;
        if (ivLength < 12 || ivLength > 16 || value.length <= 1 + ivLength + 16) {
            throw new GeneralSecurityException("Invalid encrypted session parameters");
        }
        byte[] iv = Arrays.copyOfRange(value, 1, 1 + ivLength);
        byte[] ciphertext = Arrays.copyOfRange(value, 1 + ivLength, value.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
        cipher.updateAAD(AAD);
        return cipher.doFinal(ciphertext);
    }

    private SecretKey getOrCreateKey() throws GeneralSecurityException {
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) {
                return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
            }
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build();
            generator.init(spec);
            return generator.generateKey();
        } catch (GeneralSecurityException error) {
            throw error;
        } catch (Exception error) {
            throw new GeneralSecurityException("Android Keystore is unavailable", error);
        }
    }

    private static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static final class Session {
        public final String accessToken;
        public final String refreshToken;
        public final String userId;
        public final long expiresAtMs;

        public Session(String accessToken, String refreshToken, String userId, long expiresAtMs) {
            this.accessToken = accessToken;
            this.refreshToken = refreshToken;
            this.userId = userId;
            this.expiresAtMs = expiresAtMs;
        }
    }
}
