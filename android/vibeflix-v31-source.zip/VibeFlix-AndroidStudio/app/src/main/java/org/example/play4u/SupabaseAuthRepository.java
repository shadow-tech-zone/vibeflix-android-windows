package org.example.play4u;

import android.content.Context;

import org.json.JSONException;

import java.io.IOException;
import java.security.GeneralSecurityException;

/** Coordinates password sign-in, refresh, and encrypted local session storage. */
public final class SupabaseAuthRepository {
    private static final long REFRESH_EARLY_MS = 60_000L;

    private final SupabaseAuthClient client;
    private final SupabaseSessionStore store;

    public SupabaseAuthRepository(Context context) {
        this(new SupabaseAuthClient(), new SupabaseSessionStore(context));
    }

    SupabaseAuthRepository(SupabaseAuthClient client, SupabaseSessionStore store) {
        this.client = client;
        this.store = store;
    }

    public boolean isConfigured() {
        return client.isConfigured();
    }

    public boolean hasSession() {
        return store.load() != null;
    }

    public SupabaseSessionStore.Session currentSession() {
        return store.load();
    }

    public synchronized SupabaseSessionStore.Session signIn(String email, String password) throws IOException {
        SupabaseSessionStore.Session session = client.signIn(email, password);
        persist(session);
        return session;
    }

    /** Returns a fresh-enough session, refreshing and rotating tokens when needed. */
    public synchronized SupabaseSessionStore.Session getValidSession() throws IOException {
        SupabaseSessionStore.Session session = store.load();
        if (session == null) return null;
        if (session.expiresAtMs > System.currentTimeMillis() + REFRESH_EARLY_MS) return session;
        try {
            SupabaseSessionStore.Session refreshed = client.refresh(session.refreshToken);
            persist(refreshed);
            return refreshed;
        } catch (SupabaseAuthClient.AuthException error) {
            if (error.statusCode == 400 || error.statusCode == 401) store.clear();
            throw error;
        }
    }

    /** Clears local credentials even if the remote logout request is unavailable. */
    public synchronized void signOut() throws IOException {
        SupabaseSessionStore.Session session = store.load();
        store.clear();
        if (session != null) client.signOut(session.accessToken);
    }

    private void persist(SupabaseSessionStore.Session session) throws IOException {
        try {
            store.save(session);
        } catch (GeneralSecurityException | JSONException error) {
            throw new IOException("Could not securely save the Supabase session on this device.", error);
        }
    }
}
