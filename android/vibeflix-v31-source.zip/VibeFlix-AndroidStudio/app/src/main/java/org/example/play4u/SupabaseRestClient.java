package org.example.play4u;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Minimal authenticated PostgREST access for the user-scoped My List tables. */
public final class SupabaseRestClient {
    private static final int CONNECT_TIMEOUT_MS = 12000;
    private static final int READ_TIMEOUT_MS = 20000;
    private static final int MAX_RESPONSE_BYTES = 1024 * 1024;

    private final String baseUrl;
    private final String publishableKey;
    private final SupabaseAuthClient keyValidator;

    public SupabaseRestClient() {
        this(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_PUBLISHABLE_KEY);
    }

    SupabaseRestClient(String baseUrl, String publishableKey) {
        this.baseUrl = trimTrailingSlash(baseUrl);
        this.publishableKey = publishableKey == null ? "" : publishableKey.trim();
        this.keyValidator = new SupabaseAuthClient(this.baseUrl, this.publishableKey);
    }

    public boolean isConfigured() {
        return keyValidator.isConfigured();
    }

    /** Fetches only rows owned by the signed-in user; RLS remains the authority. */
    public JSONArray fetchMyList(String userId, String accessToken) throws IOException {
        requireConfigured(userId, accessToken);
        String path = "/rest/v1/my_list"
                + "?select=title_id,is_present,client_updated_at,titles(id,source,title,poster_url,metadata)"
                + "&user_id=eq." + encode(userId)
                + "&order=client_updated_at.asc"
                + "&limit=1000";
        byte[] response = request(path, "GET", null, accessToken, null);
        try {
            return new JSONArray(new String(response, StandardCharsets.UTF_8));
        } catch (JSONException error) {
            throw new IOException("Supabase returned an invalid My List response.", error);
        }
    }

    /** Upserts safe title metadata before any My List rows reference it. */
    public void upsertTitles(JSONArray rows, String accessToken) throws IOException {
        if (rows == null || rows.length() == 0) return;
        requireConfigured(accessToken);
        String path = "/rest/v1/titles?on_conflict=user_id%2Cid";
        request(path, "POST", rows.toString().getBytes(StandardCharsets.UTF_8), accessToken,
                "resolution=merge-duplicates,return=minimal");
    }

    /** Upserts My List state; the database trigger rejects stale/equal timestamps. */
    public JSONArray upsertMyList(JSONArray rows, String accessToken) throws IOException {
        if (rows == null || rows.length() == 0) return new JSONArray();
        requireConfigured(accessToken);
        String path = "/rest/v1/my_list?on_conflict=user_id%2Ctitle_id";
        byte[] response = request(path, "POST", rows.toString().getBytes(StandardCharsets.UTF_8), accessToken,
                "resolution=merge-duplicates,return=representation");
        if (response.length == 0) return new JSONArray();
        try {
            return new JSONArray(new String(response, StandardCharsets.UTF_8));
        } catch (JSONException error) {
            throw new IOException("Supabase returned an invalid My List write response.", error);
        }
    }

    private byte[] request(String path, String method, byte[] body, String accessToken,
                           String preference) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(baseUrl + path).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setUseCaches(false);
            connection.setRequestProperty("apikey", publishableKey);
            connection.setRequestProperty("Authorization", "Bearer " + accessToken);
            connection.setRequestProperty("Accept", "application/json");
            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                if (preference != null) connection.setRequestProperty("Prefer", preference);
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body);
                }
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            byte[] response = stream == null ? new byte[0] : readBounded(stream);
            if (status < 200 || status >= 300) {
                throw new IOException("Supabase My List sync failed (HTTP " + status + ").");
            }
            return response;
        } catch (IOException error) {
            if (error.getMessage() != null && error.getMessage().startsWith("Supabase My List sync failed")) throw error;
            throw new IOException("Could not reach Supabase. Local My List data was kept.", error);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static byte[] readBounded(InputStream input) throws IOException {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) throw new IOException("Supabase response was too large.");
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        }
    }

    private void requireConfigured(String userId, String accessToken) throws IOException {
        requireConfigured(accessToken);
        if (userId == null || userId.trim().isEmpty()) {
            throw new IOException("Sign in before syncing the library.");
        }
    }

    private void requireConfigured(String accessToken) throws IOException {
        if (!isConfigured()) throw new IOException("Cloud sync is not configured in this build.");
        if (accessToken == null || accessToken.trim().isEmpty()) {
            throw new IOException("Sign in before syncing the library.");
        }
    }

    private static String encode(String value) throws IOException {
        try {
            return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
        } catch (Exception error) {
            throw new IOException("Could not encode the library request.", error);
        }
    }

    private static String trimTrailingSlash(String value) {
        if (value == null) return "";
        String result = value.trim();
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }
}
