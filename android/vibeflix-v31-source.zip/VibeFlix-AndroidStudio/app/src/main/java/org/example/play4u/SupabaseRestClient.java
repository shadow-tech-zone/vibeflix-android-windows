package org.example.play4u;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Minimal authenticated PostgREST access for user-scoped account-library tables. */
public class SupabaseRestClient {
    private static final int CONNECT_TIMEOUT_MS = 12000;
    private static final int READ_TIMEOUT_MS = 20000;
    private static final int MAX_RESPONSE_BYTES = 1024 * 1024;

    private final String baseUrl;
    private final String publishableKey;
    private final SupabaseAuthClient keyValidator;

    public SupabaseRestClient() {
        this(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_PUBLISHABLE_KEY);
    }

    SupabaseRestClient(String baseUrl, String publishableKey) {
        this.baseUrl = trimTrailingSlash(baseUrl);
        this.publishableKey = publishableKey == null ? "" : publishableKey.trim();
        this.keyValidator = new SupabaseAuthClient(this.baseUrl, this.publishableKey);
    }

    public boolean isConfigured() {
        return keyValidator.isConfigured();
    }

    /** Fetches only rows owned by the signed-in user; RLS remains the authority. */
    public JSONArray fetchMyList(String userId, String accessToken) throws IOException {
        requireConfigured(userId, accessToken);
        String path = "/rest/v1/my_list"
                + "?select=title_id,is_present,client_updated_at,titles(id,source,title,poster_url,metadata)"
                + "&user_id=eq." + encode(userId)
                + "&order=client_updated_at.asc"
                + "&limit=1000";
        byte[] response = request(path, "GET", null, accessToken, null);
        try {
            return new JSONArray(new String(response, StandardCharsets.UTF_8));
        } catch (JSONException error) {
            throw new IOException("Supabase returned an invalid My List response.", error);
        }
    }

    /** Reads latest per-title History state plus only approved catalog metadata. */
    public JSONArray fetchWatchHistory(String userId, String accessToken) throws IOException {
        String path = "/rest/v1/watch_history"
                + "?select=title_id,is_present,client_updated_at,titles(id,source,title,poster_url,metadata)"
                + "&user_id=eq." + encode(userId) + "&order=client_updated_at.asc&limit=1000";
        return getRows(path, userId, accessToken, "History");
    }

    /** Reads per-episode progress; no stream or playback URL is selected. */
    public JSONArray fetchWatchProgress(String userId, String accessToken) throws IOException {
        String path = "/rest/v1/watch_progress"
                + "?select=title_id,episode_key,position_ms,duration_ms,completed,is_present,client_updated_at,titles(id,source,title,poster_url,metadata)"
                + "&user_id=eq." + encode(userId) + "&order=client_updated_at.asc&limit=1000";
        return getRows(path, userId, accessToken, "playback progress");
    }

    public JSONArray fetchContinueHidden(String userId, String accessToken) throws IOException {
        String path = "/rest/v1/continue_hidden"
                + "?select=title_id,is_hidden,client_updated_at,titles(id,source,title,poster_url,metadata)"
                + "&user_id=eq." + encode(userId) + "&order=client_updated_at.asc&limit=1000";
        return getRows(path, userId, accessToken, "Continue Watching state");
    }

    public JSONArray fetchLibraryState(String userId, String accessToken) throws IOException {
        String path = "/rest/v1/user_library_state?select=history_cleared_at"
                + "&user_id=eq." + encode(userId) + "&limit=1";
        return getRows(path, userId, accessToken, "library state");
    }

    private JSONArray getRows(String path, String userId, String accessToken, String label) throws IOException {
        requireConfigured(userId, accessToken);
        byte[] response = request(path, "GET", null, accessToken, null);
        try {
            return new JSONArray(new String(response, StandardCharsets.UTF_8));
        } catch (JSONException error) {
            throw new IOException("Supabase returned invalid " + label + " data.", error);
        }
    }

    /** Upserts safe title metadata before any cloud library state references it. */
    public void upsertTitles(JSONArray rows, String accessToken) throws IOException {
        if (rows == null || rows.length() == 0) return;
        requireConfigured(accessToken);
        String path = "/rest/v1/titles?on_conflict=user_id%2Cid";
        request(path, "POST", rows.toString().getBytes(StandardCharsets.UTF_8), accessToken,
                "resolution=merge-duplicates,return=minimal");
    }

    /** Upserts My List state; the database trigger rejects stale/equal timestamps. */
    public JSONArray upsertMyList(JSONArray rows, String accessToken) throws IOException {
        if (rows == null || rows.length() == 0) return new JSONArray();
        requireConfigured(accessToken);
        String path = "/rest/v1/my_list?on_conflict=user_id%2Ctitle_id";
        byte[] response = request(path, "POST", rows.toString().getBytes(StandardCharsets.UTF_8), accessToken,
                "resolution=merge-duplicates,return=representation");
        if (response.length == 0) return new JSONArray();
        try {
            return new JSONArray(new String(response, StandardCharsets.UTF_8));
        } catch (JSONException error) {
            throw new IOException("Supabase returned an invalid My List write response.", error);
        }
    }

    public JSONArray upsertWatchHistory(JSONArray rows, String accessToken) throws IOException {
        return upsertRows("/rest/v1/watch_history?on_conflict=user_id%2Ctitle_id", rows, accessToken, "History");
    }

    public JSONArray upsertWatchProgress(JSONArray rows, String accessToken) throws IOException {
        return upsertRows("/rest/v1/watch_progress?on_conflict=user_id%2Ctitle_id%2Cepisode_key", rows, accessToken, "playback progress");
    }

    public JSONArray upsertContinueHidden(JSONArray rows, String accessToken) throws IOException {
        return upsertRows("/rest/v1/continue_hidden?on_conflict=user_id%2Ctitle_id", rows, accessToken, "Continue Watching state");
    }

    public JSONArray upsertLibraryState(JSONArray rows, String accessToken) throws IOException {
        return upsertRows("/rest/v1/user_library_state?on_conflict=user_id", rows, accessToken, "library state");
    }

    private JSONArray upsertRows(String path, JSONArray rows, String accessToken, String label) throws IOException {
        if (rows == null || rows.length() == 0) return new JSONArray();
        requireConfigured(accessToken);
        byte[] response = request(path, "POST", rows.toString().getBytes(StandardCharsets.UTF_8), accessToken,
                "resolution=merge-duplicates,return=representation");
        if (response.length == 0) return new JSONArray();
        try {
            return new JSONArray(new String(response, StandardCharsets.UTF_8));
        } catch (JSONException error) {
            throw new IOException("Supabase returned invalid " + label + " write data.", error);
        }
    }

    private byte[] request(String path, String method, byte[] body, String accessToken,
                           String preference) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(baseUrl + path).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setUseCaches(false);
            connection.setRequestProperty("apikey", publishableKey);
            connection.setRequestProperty("Authorization", "Bearer " + accessToken);
            connection.setRequestProperty("Accept", "application/json");
            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                if (preference != null) connection.setRequestProperty("Prefer", preference);
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body);
                }
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            byte[] response = stream == null ? new byte[0] : readBounded(stream);
            if (status < 200 || status >= 300) {
                throw new IOException("Supabase library sync failed (HTTP " + status + ").");
            }
            return response;
        } catch (IOException error) {
            if (error.getMessage() != null && error.getMessage().startsWith("Supabase library sync failed")) throw error;
            throw new IOException("Could not reach Supabase. Local library data was kept.", error);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static byte[] readBounded(InputStream input) throws IOException {
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = stream.read(buffer)) != -1) {
                total += count;
                if (total > MAX_RESPONSE_BYTES) throw new IOException("Supabase response was too large.");
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        }
    }

    private void requireConfigured(String userId, String accessToken) throws IOException {
        requireConfigured(accessToken);
        if (userId == null || userId.trim().isEmpty()) {
            throw new IOException("Sign in before syncing the library.");
        }
    }

    private void requireConfigured(String accessToken) throws IOException {
        if (!isConfigured()) throw new IOException("Cloud sync is not configured in this build.");
        if (accessToken == null || accessToken.trim().isEmpty()) {
            throw new IOException("Sign in before syncing the library.");
        }
    }

    private static String encode(String value) throws IOException {
        try {
            return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
        } catch (Exception error) {
            throw new IOException("Could not encode the library request.", error);
        }
    }

    private static String trimTrailingSlash(String value) {
        if (value == null) return "";
        String result = value.trim();
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }
}
