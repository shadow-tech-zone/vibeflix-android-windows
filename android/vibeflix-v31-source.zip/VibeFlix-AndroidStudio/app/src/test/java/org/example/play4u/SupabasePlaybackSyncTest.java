package org.example.play4u;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class SupabasePlaybackSyncTest {
    private static final String USER_ID = "user-a";
    private static final SupabaseSessionStore.Session SESSION =
            new SupabaseSessionStore.Session("access-token", "refresh-token", USER_ID, Long.MAX_VALUE);

    @Test
    public void episodeKeysAreCanonicalAndNeverContainPlaybackUrls() {
        MainActivity.Item server1 = new MainActivity.Item("Show", "https://play4u.org/series/tt123", "", "2024");
        String key1 = SupabasePlaybackSync.episodeKey(server1,
                "https://play4u.org/series/tt123/s-2/ep-4");
        assertEquals("s2e4", key1);
        assertEquals("https://play4u.org/series/tt123/s-2/ep-4",
                SupabasePlaybackSync.playbackPath(server1, key1));
        assertFalse(key1.contains("https://"));
        assertNull(SupabasePlaybackSync.episodeKey(server1,
                "https://play4u.org/series/tt123/master.m3u8"));
        assertNull(SupabasePlaybackSync.episodeKey(server1,
                "https://play4u.org/series/tt123/s-2/ep-4?file=master.m3u8"));

        MainActivity.Item server2 = new MainActivity.Item("Show", "https://www.movy.sx/tv/123", "", "2024");
        String key2 = SupabasePlaybackSync.episodeKey(server2,
                "https://www.movy.sx/tv/123?season=3&episode=8");
        assertEquals("s3e8", key2);
        assertEquals("https://www.movy.sx/tv/123?season=3&episode=8",
                SupabasePlaybackSync.playbackPath(server2, key2));
        assertNull(SupabasePlaybackSync.episodeKey(server2,
                "https://www.movy.sx/tv/123?season=3&episode=8&file=master.m3u8"));
    }

    @Test
    public void removalAndCompletionWinTimestampTiesDeterministically() {
        assertTrue(SupabasePlaybackSync.historyLocalWinsForTest(10, false, 10, true));
        assertFalse(SupabasePlaybackSync.historyLocalWinsForTest(10, true, 10, true));
        assertTrue(SupabasePlaybackSync.historyLocalWinsForTest(11, true, 10, false));

        assertTrue(SupabasePlaybackSync.progressLocalWinsForTest(10, false, false, 0,
                10, true, false, 900));
        assertTrue(SupabasePlaybackSync.progressLocalWinsForTest(10, true, true, 0,
                10, true, false, 900));
        assertTrue(SupabasePlaybackSync.progressLocalWinsForTest(10, true, false, 901,
                10, true, false, 900));
        assertFalse(SupabasePlaybackSync.progressLocalWinsForTest(10, true, false, 900,
                10, true, false, 900));

        assertTrue(SupabasePlaybackSync.hiddenLocalWinsForTest(10, true, 10, false));
        assertFalse(SupabasePlaybackSync.hiddenLocalWinsForTest(10, false, 10, true));
    }

    @Test
    public void legacyMyListConsentDoesNotImplicitlyAuthorizePlaybackData() {
        Context context = RuntimeEnvironment.getApplication();
        SharedPreferences prefs = syncPrefs(context);
        prefs.edit().clear().putString("my_list_sync_user_id", USER_ID)
                .putString("library_sync_user_id", USER_ID).putInt("library_sync_consent_version", 1).commit();
        assertFalse(SupabaseLibrarySync.isEnabledFor(context, USER_ID));
        prefs.edit().putString("watch_progress_state_v1", "local-checkpoint").commit();
        SupabaseLibrarySync.enableFor(context, USER_ID);
        assertTrue(SupabaseLibrarySync.isEnabledFor(context, USER_ID));
        assertFalse(SupabaseLibrarySync.isEnabledFor(context, "user-b"));
        assertFalse(SupabaseLibrarySync.disableFor(context, "user-b"));
        assertTrue(SupabaseLibrarySync.isEnabledFor(context, USER_ID));
        assertTrue(SupabaseLibrarySync.disableFor(context, USER_ID));
        assertFalse(SupabaseLibrarySync.isEnabledFor(context, USER_ID));
        assertEquals("local-checkpoint", prefs.getString("watch_progress_state_v1", ""));
    }

    @Test
    public void progressTimestampsAdvanceAcrossEpisodesOfTheSameTitle() throws Exception {
        Context context = RuntimeEnvironment.getApplication();
        reset(context);
        MainActivity.Item item = new MainActivity.Item("Example", "https://play4u.org/series/tt789", "", "2024");
        item.time = System.currentTimeMillis() - 10_000L;
        writeItems(context, "watch_history", item);
        String base = "https://play4u.org/series/tt789";
        SupabasePlaybackSync.recordLocalProgress(context, item.url, base + "/s-1/ep-1", item.title, 5_000L, 50_000L, false);
        JSONObject states = new JSONObject(syncPrefs(context).getString("watch_progress_state_v1", "{}"));
        long first = states.getJSONObject(SupabaseLibrarySync.identityFor(item).id + "|s1e1").getLong("time");
        SupabasePlaybackSync.recordLocalProgress(context, item.url, base + "/s-1/ep-2", item.title, 1_000L, 50_000L, false);
        states = new JSONObject(syncPrefs(context).getString("watch_progress_state_v1", "{}"));
        long second = states.getJSONObject(SupabaseLibrarySync.identityFor(item).id + "|s1e2").getLong("time");
        assertTrue(second > first);
        assertTrue(SupabasePlaybackSync.nextHistoryTimestamp(context, item) > second);
    }

    @Test
    public void clearWatermarkAndProgressTombstonesAdvancePastEveryLocalTimestamp() throws Exception {
        Context context = RuntimeEnvironment.getApplication();
        reset(context);
        MainActivity.Item item = new MainActivity.Item("Example", "https://play4u.org/series/tt123", "", "2024");
        item.time = System.currentTimeMillis() + 60_000L;
        writeItems(context, "watch_history", item);
        String episode = "https://play4u.org/series/tt123/s-2/ep-4";
        SupabasePlaybackSync.recordLocalProgress(context, item.url, episode, item.title, 12_000L, 80_000L, false);
        SupabasePlaybackSync.recordContinueHidden(context, item, true);
        String titleId = SupabaseLibrarySync.identityFor(item).id;
        JSONObject progressRows = new JSONObject(syncPrefs(context).getString("watch_progress_state_v1", "{}"));
        long progressTime = progressRows.getJSONObject(titleId + "|s2e4").getLong("time");
        JSONObject hiddenRows = new JSONObject(syncPrefs(context).getString("continue_hidden_state_v1", "{}"));
        long hiddenTime = hiddenRows.getJSONObject(titleId).getLong("time");
        assertTrue(hiddenTime > progressTime);

        SupabasePlaybackSync.recordHistoryClear(context, Collections.singletonList(item));
        long clearAt = syncPrefs(context).getLong("history_cleared_at_ms_v1", 0L);
        assertTrue(clearAt > item.time);
        assertTrue(clearAt > progressTime);
        assertTrue(clearAt > hiddenTime);
        assertTrue(SupabasePlaybackSync.nextHistoryTimestamp(context, item) > clearAt);

        SupabasePlaybackSync.recordTitleProgressRemoval(context, item);
        JSONObject states = new JSONObject(syncPrefs(context).getString("watch_progress_state_v1", "{}"));
        JSONObject progress = states.getJSONObject(SupabaseLibrarySync.identityFor(item).id + "|s2e4");
        assertFalse(progress.getBoolean("present"));
        assertTrue(progress.getLong("time") > clearAt);
        assertFalse(progress.toString().contains("/s-2/ep-4"));
    }

    @Test
    public void localFirstSyncRestoresSafeResumeAndPropagatesTitleRemoval() throws Exception {
        Context context = RuntimeEnvironment.getApplication();
        reset(context);
        SupabaseLibrarySync.enableFor(context, USER_ID);
        MainActivity.Item item = new MainActivity.Item("Show", "https://play4u.org/series/tt123", "https://img.example/poster.jpg", "2024");
        item.time = System.currentTimeMillis() - 5_000L;
        writeItems(context, "watch_history", item);
        String playbackPath = "https://play4u.org/series/tt123/s-2/ep-4";
        SupabasePlaybackSync.recordLocalProgress(context, item.url, playbackPath, item.title, 45_000L, 120_000L, false);
        SupabasePlaybackSync.recordContinueHidden(context, item, true);

        FakeRest rest = new FakeRest();
        SupabasePlaybackSync sync = new SupabasePlaybackSync(context, rest);
        SupabasePlaybackSync.SyncResult first = sync.sync(SESSION);
        assertEquals(1, first.historyTitles);
        assertEquals(1, first.resumableEpisodes);
        assertEquals("s2e4", rest.lastProgress.optJSONObject(0).getString("episode_key"));
        assertEquals(45_000L, rest.lastProgress.optJSONObject(0).getLong("position_ms"));
        assertTrue(rest.lastHidden.optJSONObject(0).getBoolean("is_hidden"));
        assertEquals("/series/tt123", rest.lastTitles.optJSONObject(0)
                .optJSONObject("metadata").optString("catalog_path"));
        assertFalse(rest.lastHistory.toString().contains("play4u.org/series/tt123/s-2/ep-4"));
        assertFalse(rest.lastProgress.toString().contains("play4u.org/series/tt123/s-2/ep-4"));
        assertFalse(rest.lastProgress.toString().contains("master.m3u8"));
        assertFalse(rest.lastProgress.toString().contains("access-token"));

        // A second installation starts with no local copy and restores state from the fake cloud.
        clearDeviceLibrary(context);
        sync.sync(SESSION);
        JSONArray restored = new JSONArray(context.getSharedPreferences("watch_history", Context.MODE_PRIVATE)
                .getString("items", "[]"));
        assertEquals(1, restored.length());
        assertEquals(item.url, restored.getJSONObject(0).getString("url"));
        assertEquals(playbackPath, context.getSharedPreferences("resume_titles", Context.MODE_PRIVATE)
                .getString(item.url, ""));
        assertEquals(45_000L, context.getSharedPreferences("playback_position", Context.MODE_PRIVATE)
                .getLong(playbackPath, 0L));
        assertTrue(context.getSharedPreferences("continue_hidden", Context.MODE_PRIVATE)
                .getBoolean(item.url, false));

        // A title removal creates durable History, progress, and hidden-state tombstones.
        item.time = restored.getJSONObject(0).getLong("time");
        SupabasePlaybackSync.recordHistoryRemoval(context, item);
        SupabasePlaybackSync.recordTitleProgressRemoval(context, item);
        SupabasePlaybackSync.recordContinueHidden(context, item, false);
        writeItems(context, "watch_history", (MainActivity.Item) null);
        sync.sync(SESSION);
        assertFalse(rest.lastHistory.optJSONObject(0).getBoolean("is_present"));
        assertFalse(rest.lastProgress.optJSONObject(0).getBoolean("is_present"));
        assertFalse(rest.lastHidden.optJSONObject(0).getBoolean("is_hidden"));

        // Another clean installation receives the tombstones and cannot restore the title/resume.
        clearDeviceLibrary(context);
        SupabasePlaybackSync.SyncResult removed = sync.sync(SESSION);
        assertEquals(0, removed.historyTitles);
        assertEquals(0, new JSONArray(context.getSharedPreferences("watch_history", Context.MODE_PRIVATE)
                .getString("items", "[]")).length());
        assertEquals(0L, context.getSharedPreferences("playback_position", Context.MODE_PRIVATE)
                .getLong(playbackPath, 0L));
        assertFalse(context.getSharedPreferences("continue_hidden", Context.MODE_PRIVATE)
                .getBoolean(item.url, false));
    }

    @Test
    public void clearAllUploadsWatermarkAndTombstones() throws Exception {
        Context context = RuntimeEnvironment.getApplication();
        reset(context);
        SupabaseLibrarySync.enableFor(context, USER_ID);
        MainActivity.Item item = new MainActivity.Item("Example", "/watch/tt456", "", "2023");
        item.time = System.currentTimeMillis() - 10_000L;
        writeItems(context, "watch_history", item);
        SupabasePlaybackSync.recordLocalProgress(context, item.url,
                "https://play4u.org/watch/tt456", item.title, 30_000L, 100_000L, false);
        SupabasePlaybackSync.recordContinueHidden(context, item, true);
        SupabasePlaybackSync.recordHistoryClear(context, Collections.singletonList(item));
        SupabasePlaybackSync.recordTitleProgressRemoval(context, item);
        SupabasePlaybackSync.recordContinueHidden(context, item, false);
        writeItems(context, "watch_history", (MainActivity.Item) null);

        FakeRest rest = new FakeRest();
        SupabasePlaybackSync.SyncResult result = new SupabasePlaybackSync(context, rest).sync(SESSION);
        assertEquals(0, result.historyTitles);
        assertTrue(rest.libraryState.length() == 1);
        assertTrue(rest.libraryState.getJSONObject(0).has("history_cleared_at"));
        assertFalse(rest.lastHistory.optJSONObject(0).getBoolean("is_present"));
        assertFalse(rest.lastProgress.optJSONObject(0).getBoolean("is_present"));
        assertFalse(rest.lastHidden.optJSONObject(0).getBoolean("is_hidden"));
    }

    private static SharedPreferences syncPrefs(Context context) {
        return context.getSharedPreferences("vibeflix_supabase_library_sync", Context.MODE_PRIVATE);
    }

    private static void reset(Context context) {
        for (String name : new String[]{"vibeflix_supabase_library_sync", "watch_history", "watch_history_movy",
                "my_list", "my_list_movy", "continue_hidden", "playback_position", "playback_duration",
                "resume_titles", "episode_names"}) {
            context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit();
        }
    }

    private static void clearDeviceLibrary(Context context) {
        for (String name : new String[]{"watch_history", "watch_history_movy", "continue_hidden",
                "playback_position", "playback_duration", "resume_titles", "episode_names"}) {
            context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit();
        }
        syncPrefs(context).edit().remove("watch_history_tombstones_v1")
                .remove("watch_progress_state_v1").remove("continue_hidden_state_v1")
                .remove("history_cleared_at_ms_v1").commit();
    }

    private static void writeItems(Context context, String name, MainActivity.Item item) throws JSONException {
        JSONArray rows = new JSONArray();
        if (item != null) {
            JSONObject row = new JSONObject();
            row.put("title", item.title);
            row.put("url", item.url);
            row.put("img", item.img);
            row.put("year", item.year);
            row.put("time", item.time);
            rows.put(row);
        }
        context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().putString("items", rows.toString()).commit();
    }

    private static final class FakeRest extends SupabaseRestClient {
        private final Map<String, JSONObject> titles = new HashMap<>();
        private JSONArray history = new JSONArray();
        private JSONArray progress = new JSONArray();
        private JSONArray hidden = new JSONArray();
        private JSONArray libraryState = new JSONArray();
        JSONArray lastTitles = new JSONArray();
        JSONArray lastHistory = new JSONArray();
        JSONArray lastProgress = new JSONArray();
        JSONArray lastHidden = new JSONArray();

        FakeRest() { super("https://project.supabase.co", "sb_publishable_test"); }

        @Override public JSONArray fetchWatchHistory(String userId, String token) { return copy(history); }
        @Override public JSONArray fetchWatchProgress(String userId, String token) { return copy(progress); }
        @Override public JSONArray fetchContinueHidden(String userId, String token) { return copy(hidden); }
        @Override public JSONArray fetchLibraryState(String userId, String token) { return copy(libraryState); }

        @Override public void upsertTitles(JSONArray rows, String token) {
            lastTitles = copy(rows);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row != null) titles.put(row.optString("id", ""), copy(row));
            }
        }

        @Override public JSONArray upsertWatchHistory(JSONArray rows, String token) {
            lastHistory = copy(rows);
            history = decorate(rows);
            return copy(rows);
        }

        @Override public JSONArray upsertWatchProgress(JSONArray rows, String token) {
            lastProgress = copy(rows);
            progress = decorate(rows);
            return copy(rows);
        }

        @Override public JSONArray upsertContinueHidden(JSONArray rows, String token) {
            lastHidden = copy(rows);
            hidden = decorate(rows);
            return copy(rows);
        }

        @Override public JSONArray upsertLibraryState(JSONArray rows, String token) {
            libraryState = copy(rows);
            return copy(rows);
        }

        private JSONArray decorate(JSONArray source) {
            JSONArray out = new JSONArray();
            for (int i = 0; i < source.length(); i++) {
                JSONObject sourceRow = source.optJSONObject(i);
                if (sourceRow == null) continue;
                JSONObject row = copy(sourceRow);
                JSONObject title = titles.get(row.optString("title_id", ""));
                if (title != null) try { row.put("titles", copy(title)); } catch (JSONException ignored) { }
                out.put(row);
            }
            return out;
        }

        private static JSONArray copy(JSONArray source) {
            try { return source == null ? new JSONArray() : new JSONArray(source.toString()); }
            catch (JSONException impossible) { throw new AssertionError(impossible); }
        }

        private static JSONObject copy(JSONObject source) {
            try { return source == null ? new JSONObject() : new JSONObject(source.toString()); }
            catch (JSONException impossible) { throw new AssertionError(impossible); }
        }
    }
}
