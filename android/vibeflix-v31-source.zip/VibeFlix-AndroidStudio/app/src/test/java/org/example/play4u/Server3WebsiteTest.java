package org.example.play4u;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.Test;

public class Server3WebsiteTest {
    @Test public void readsCatalogAndDeduplicatesTitles() {
        String html = "<article class='item'><div class='poster'><img src='https://images.example/poster.jpg'></div>"
                + "<div class='data'><h3><a href='/movie/example-123/'>Example</a></h3><span>2026</span></div></article>";
        List<Server3Website.Title> titles = Server3Website.parseCatalog(html + html);
        assertEquals(1, titles.size());
        assertEquals("Example", titles.get(0).name);
        assertEquals("https://newhdmovie2.fast/movie/example-123/", titles.get(0).url);
        assertEquals("2026", titles.get(0).year);
    }

    @Test public void rejectsUnexpectedOrUnsafeHosts() {
        assertFalse(Server3Website.isTitleUrl("https://newhdmovie2.fast.evil.test/movie/example/"));
        assertFalse(Server3Website.isTitleUrl("https://newhdmovie2.fast@evil.test/movie/example/"));
        assertFalse(Server3Website.isTitleUrl("http://newhdmovie2.fast/movie/example/"));
        assertFalse(Server3Website.isTitleUrl("https://newhdmovie2.fast/movie/example/?token=x"));
        assertFalse(Server3Website.isTitleUrl("https://newhdmovie2.fast/movie/%2e%2e/"));
        assertFalse(Server3Website.isTitleUrl("https://newhdmovie2.fast/movie/abc%2Fdef/"));
        assertTrue(Server3Website.isTitleUrl("https://newhdmovie2.fast/movie/ol%C3%A9-123/"));
    }

    @Test public void findsFirstPartyEmbedAndRejectsUnknownHosts() {
        String html = "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/ABC123&quot;&gt;&lt;/iframe&gt;'>"
                + "<span class='title'>Ultra Stream V3</span></li>"
                + "<li data-source-embed='&lt;iframe src=&quot;https://evil.test/x&quot;&gt;&lt;/iframe&gt;'></li>";
        List<Server3Website.Source> sources = Server3Website.parseSources(html);
        assertEquals(1, sources.size());
        assertEquals("Ultra Stream V3", sources.get(0).label);
        assertEquals("https://newhdmovie2.fast/hdm2-player/ABC123", sources.get(0).embedUrl);
    }

    @Test public void extractsOnlyAllowedPlayerPlaylists() {
        String html = "<script id='player-loader' data-stream-url='/playlist/example?v=1&amp;tok=test'></script>";
        assertEquals("https://hdm2.biz/playlist/example?v=1&tok=test",
                Server3Website.parsePlaylist(html, "https://hdm2.biz/play?v=example"));
        assertEquals("", Server3Website.parsePlaylist(html, "https://evil.test/play"));
        assertEquals("", Server3Website.parsePlaylist("<script id='player-loader' data-stream-url='https://evil.test/playlist/x'></script>", "https://hdm2.biz/play"));
    }
    @Test public void sourceKeysRemainStableWhenSourcesReorder() {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        Server3Website.Source ep = new Server3Website.Source("EP02", "https://newhdmovie2.fast/hdm2-player/EP02");
        String saved = Server3Website.playbackPath(title, ep);
        assertEquals(title + "?s3source=EP02", saved);
        assertEquals(title, Server3Website.titleFromPlayback(saved));
        assertEquals("", Server3Website.titleFromPlayback(saved + "&extra=1"));
        assertEquals("", Server3Website.playbackPath(title, new Server3Website.Source("bad", "https://evil.test/hdm2-player/EP02")));
    }

    @Test public void nextPageMustRemainOnProvider() throws Exception {
        assertTrue(Server3Website.hasNextPage("<a class='next' href='/page/2/'>Next</a>"));
        assertFalse(Server3Website.hasNextPage("<a class='next' href='https://evil.test/page/2/'>Next</a>"));
        assertEquals("https://newhdmovie2.fast/page/2/?s=hello+world", Server3Website.catalogUrl("hello world", 2));
    }
    @Test public void resolvesFreshPlaylistThroughAllowedRedirects() throws Exception {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        String source = title + "?s3source=EP02";
        String choices = "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/EP01&quot;&gt;&lt;/iframe&gt;'></li>"
                + "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/EP02&quot;&gt;&lt;/iframe&gt;'></li>";
        java.util.List<String> requested = new java.util.ArrayList<>();
        Server3Website.Fetcher mock = (url, referrer) -> {
            requested.add(url);
            if (url.equals(title)) return new Server3Website.Response(200, null, choices);
            if (url.equals("https://newhdmovie2.fast/hdm2-player/EP02")) return new Server3Website.Response(302, "https://hdm2.biz/play?v=EP02&auth=test", "");
            if (url.startsWith("https://hdm2.biz/play?")) return new Server3Website.Response(200, null, "<script id='player-loader' data-stream-url='/playlist/example?tok=test'></script>");
            throw new AssertionError("Unexpected request");
        };
        assertEquals("https://hdm2.biz/playlist/example?tok=test", Server3Website.resolvePlaylist(source, mock));
        assertEquals(3, requested.size());
        assertEquals("https://newhdmovie2.fast/hdm2-player/EP02", requested.get(1));
    }

    @Test public void resolverDoesNotFollowUntrustedRedirect() throws Exception {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        int[] calls = {0};
        Server3Website.Fetcher mock = (url, referrer) -> {
            calls[0]++;
            if (url.equals(title)) return new Server3Website.Response(200, null, "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/ABC&quot;&gt;&lt;/iframe&gt;'></li>");
            return new Server3Website.Response(302, "https://evil.test/play", "");
        };
        try { Server3Website.resolvePlaylist(title, mock); fail("Untrusted redirect must fail"); }
        catch (java.io.IOException expected) { assertEquals(2, calls[0]); }
    }
    @Test public void missingEpisodeNeverFallsBackToAnotherSource() throws Exception {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        int[] calls = {0};
        Server3Website.Fetcher mock = (url, referrer) -> {
            calls[0]++;
            return new Server3Website.Response(200, null, "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/EP01&quot;&gt;&lt;/iframe&gt;'></li>");
        };
        try { Server3Website.resolvePlaylist(title + "?s3source=EP02", mock); fail("Missing episode must not fall back"); }
        catch (java.io.IOException expected) { assertEquals(1, calls[0]); }
    }

    @Test public void blockedPlayerFailsWithoutUsingAnOldPlaylist() throws Exception {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        int[] calls = {0};
        Server3Website.Fetcher mock = (url, referrer) -> {
            calls[0]++;
            if (url.equals(title)) return new Server3Website.Response(200, null, "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/ABC&quot;&gt;&lt;/iframe&gt;'></li>");
            if (url.contains("/hdm2-player/")) return new Server3Website.Response(302, "https://hdm2.biz/play?v=ABC", "");
            return new Server3Website.Response(403, null, "Access denied");
        };
        try { Server3Website.resolvePlaylist(title, mock); fail("Blocked player must fail"); }
        catch (java.io.IOException expected) { assertEquals(3, calls[0]); }
    }
    @Test public void episodicLabelsAreIdentifiedAndSortedWithoutGuessing() {
        assertEquals(1, Server3Website.episodeNumber("Ultra Stream V3 EP01"));
        assertEquals(12, Server3Website.episodeNumber("Ultra Stream V3 EP12"));
        assertEquals(0, Server3Website.episodeNumber("Ultra Stream V3"));
        assertEquals(0, Server3Website.episodeNumber("Ultra Stream V3 EP01-EP04"));
        assertEquals(0, Server3Website.episodeNumber("Ultra Stream V3 EP00"));
        java.util.List<Server3Website.Source> sources = java.util.Arrays.asList(
            new Server3Website.Source("Ultra Stream V3 EP03", "https://newhdmovie2.fast/hdm2-player/C"),
            new Server3Website.Source("Ultra Stream V3", "https://newhdmovie2.fast/hdm2-player/M"),
            new Server3Website.Source("Ultra Stream V3 EP01", "https://newhdmovie2.fast/hdm2-player/A"),
            new Server3Website.Source("Ultra Stream V3 EP02", "https://newhdmovie2.fast/hdm2-player/B"));
        java.util.List<Server3Website.Source> episodes = Server3Website.episodeSources(sources);
        assertEquals(3, episodes.size());
        assertEquals("Ultra Stream V3 EP01", episodes.get(0).label);
        assertEquals("Ultra Stream V3 EP03", episodes.get(2).label);
    }

    @Test public void nextEpisodePreservesStreamAndNeverGuessesMissingCurrent() {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        Server3Website.Source a = new Server3Website.Source("Ultra Stream V3 EP01", "https://newhdmovie2.fast/hdm2-player/A");
        Server3Website.Source b = new Server3Website.Source("Ultra Stream V3 EP02", "https://newhdmovie2.fast/hdm2-player/B");
        Server3Website.Source alternate = new Server3Website.Source("Alternate EP02", "https://newhdmovie2.fast/hdm2-player/C");
        java.util.List<Server3Website.Source> sources = java.util.Arrays.asList(alternate, a, b);
        assertEquals(Server3Website.playbackPath(title, b), Server3Website.nextEpisode(title, Server3Website.playbackPath(title, a), sources));
        assertEquals("", Server3Website.nextEpisode(title, Server3Website.playbackPath(title, b), sources));
        assertEquals("", Server3Website.nextEpisode(title, title, sources));
        assertEquals("", Server3Website.nextEpisode(title, title + "?s3source=missing", sources));
        assertEquals("", Server3Website.nextEpisode(title, "https://newhdmovie2.fast/movie/other/?s3source=A", sources));
    }

    @Test public void defaultResolutionIdentifiesFirstSourceForResume() throws Exception {
        String title = "https://newhdmovie2.fast/movie/example-123/";
        String choices = "<li data-source-embed='&lt;iframe src=&quot;/hdm2-player/EP01&quot;&gt;&lt;/iframe&gt;'><span class='title'>Ultra Stream V3 EP01</span></li>";
        Server3Website.Fetcher mock = (url, referrer) -> {
            if (url.equals(title)) return new Server3Website.Response(200, null, choices);
            if (url.endsWith("/hdm2-player/EP01")) return new Server3Website.Response(302, "https://hdm2.biz/play?v=EP01&auth=test", "");
            return new Server3Website.Response(200, null, "<script id='player-loader' data-stream-url='/playlist/example?tok=test'></script>");
        };
        Server3Website.Resolution resolved = Server3Website.resolve(title, mock);
        assertEquals(title + "?s3source=EP01", resolved.playbackPath);
        assertEquals("https://hdm2.biz/playlist/example?tok=test", resolved.playlistUrl);
    }
    @Test public void extractsSearchStyleCards() {
        String html = "<div class='result-item'><div class='image'><img src='https://images.example/poster.jpg'></div>"
                + "<div class='details'><div class='title'><a href='/movie/search-hit-42/'>Search hit</a></div>"
                + "<div class='year'>2024</div></div></div>";
        List<Server3Website.Title> titles = Server3Website.parseCatalog(html);
        assertEquals(1, titles.size());
        assertEquals("Search hit", titles.get(0).name);
        assertEquals("2024", titles.get(0).year);
    }

    @Test public void genresUseOnlyProviderLinksAndSafePaths() throws Exception {
        String html = "<a href='/genre/bollywood/'>Bollywood</a><a href='/genre/bollywood/'>Duplicate</a>"
                + "<a href='https://evil.test/genre/fake/'>Fake</a><a href='/genre/hindi-dubbed/'>Hindi dubbed</a>";
        java.util.Map<String,String> genres = Server3Website.parseGenres(html);
        assertEquals(2, genres.size());
        assertEquals("Bollywood", genres.get("bollywood"));
        assertEquals("https://newhdmovie2.fast/genre/hindi-webseries/page/2/", Server3Website.genreUrl("hindi-webseries", 2));
        try { Server3Website.genreUrl("../other", 1); fail("Invalid category must fail"); }
        catch (java.io.IOException expected) { }
    }
    @Test public void detailsUseVisibleRatingAndGenresNotPromotionalDescription() {
        String html = "<meta property='og:description' content='Download advert'><div class='sheader'><div class='srating'><div class='promedio'>6.7</div></div>"
            + "<div class='sgeneros'><a>Fantasy</a><a>Horror</a><a>Fantasy</a></div></div>";
        Server3Website.Details d = Server3Website.parseDetails(html);
        assertEquals("6.7", d.rating);
        assertEquals(2, d.genres.size());
        assertEquals("Fantasy", d.genres.get(0));
        assertEquals("", Server3Website.parseDetails("<div class='sheader'><div class='srating'><div class='promedio'>99.9</div></div></div>").rating);
    }
}
