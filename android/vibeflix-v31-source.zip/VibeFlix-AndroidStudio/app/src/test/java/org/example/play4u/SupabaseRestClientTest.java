package org.example.play4u;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SupabaseRestClientTest {
    private static final String BASE_URL = "https://vibeflix-sync.supabase.co";
    private static final String PUBLISHABLE_KEY = "sb_publishable_test";

    @Test
    public void fetchMyListReadsEveryStableOrderedPage() throws Exception {
        List<FakeConnection> requests = new ArrayList<>();
        SupabaseRestClient client = new SupabaseRestClient(BASE_URL, PUBLISHABLE_KEY, url -> {
            int offset = queryInt(url, "offset");
            int start = Math.min(offset, 102);
            int end = Math.min(start + SupabaseRestClient.ROW_BATCH_SIZE, 102);
            FakeConnection connection = new FakeConnection(url, rowsJson(start, end));
            requests.add(connection);
            return connection;
        });

        JSONArray rows = client.fetchMyList("user-a", "access-token");

        assertEquals(102, rows.length());
        assertEquals(2, requests.size());
        assertTrue(requests.get(0).requestUrl().toString().contains("order=title_id.asc&limit=100&offset=0"));
        assertTrue(requests.get(1).requestUrl().toString().contains("order=title_id.asc&limit=100&offset=100"));
        assertEquals("title-0", rows.getJSONObject(0).getString("title_id"));
        assertEquals("title-101", rows.getJSONObject(101).getString("title_id"));
    }

    @Test
    public void uploadsLargeTitleAndStateSetsInBoundedBatches() throws Exception {
        JSONArray rows = new JSONArray();
        for (int i = 0; i < 205; i++) {
            rows.put(new JSONObject().put("title_id", "title-" + i));
        }

        List<FakeConnection> requests = new ArrayList<>();
        SupabaseRestClient client = new SupabaseRestClient(BASE_URL, PUBLISHABLE_KEY, url -> {
            FakeConnection connection = new FakeConnection(url, "[]");
            requests.add(connection);
            return connection;
        });

        client.upsertTitles(rows, "access-token");
        assertBatchSizes(requests, rows.length());

        requests.clear();
        JSONArray accepted = client.upsertWatchProgress(rows, "access-token");
        assertEquals(0, accepted.length());
        assertBatchSizes(requests, rows.length());
        assertTrue(requests.get(0).requestUrl().getPath().endsWith("/watch_progress"));
    }

    private static void assertBatchSizes(List<FakeConnection> requests, int expectedTotal) throws Exception {
        assertEquals(3, requests.size());
        int total = 0;
        int[] expected = {100, 100, 5};
        for (int i = 0; i < requests.size(); i++) {
            JSONArray batch = new JSONArray(new String(requests.get(i).requestBody.toByteArray(), StandardCharsets.UTF_8));
            assertEquals(expected[i], batch.length());
            assertTrue(batch.length() <= SupabaseRestClient.ROW_BATCH_SIZE);
            total += batch.length();
        }
        assertEquals(expectedTotal, total);
    }

    private static int queryInt(URL url, String name) throws Exception {
        for (String pair : url.getQuery().split("&")) {
            String[] parts = pair.split("=", 2);
            if (parts.length == 2 && name.equals(URLDecoder.decode(parts[0], "UTF-8"))) {
                return Integer.parseInt(URLDecoder.decode(parts[1], "UTF-8"));
            }
        }
        throw new AssertionError("Missing query parameter " + name + " in " + url);
    }

    private static String rowsJson(int start, int end) throws Exception {
        JSONArray rows = new JSONArray();
        for (int i = start; i < end; i++) {
            rows.put(new JSONObject().put("title_id", "title-" + i));
        }
        return rows.toString();
    }

    private static final class FakeConnection extends HttpURLConnection {
        private final byte[] response;
        private final ByteArrayOutputStream requestBody = new ByteArrayOutputStream();

        FakeConnection(URL url, String response) {
            super(url);
            this.response = response.getBytes(StandardCharsets.UTF_8);
        }

        URL requestUrl() { return url; }

        @Override public void disconnect() { }
        @Override public boolean usingProxy() { return false; }
        @Override public void connect() { }
        @Override public int getResponseCode() { return HTTP_OK; }
        @Override public InputStream getInputStream() { return new ByteArrayInputStream(response); }
        @Override public OutputStream getOutputStream() { return requestBody; }
    }
}
