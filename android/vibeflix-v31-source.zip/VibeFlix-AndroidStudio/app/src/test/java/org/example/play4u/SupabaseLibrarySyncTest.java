package org.example.play4u;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class SupabaseLibrarySyncTest {
    @Test
    public void titleIdsAreStableAndSourceNamespaced() {
        MainActivity.Item server1 = new MainActivity.Item("Example", "/watch/tt123", "https://img.example/poster.jpg", "2024");
        MainActivity.Item server2 = new MainActivity.Item("Example", "https://www.movy.sx/movie/123", "https://img.example/poster.jpg", "2024");

        SupabaseLibrarySync.TitleIdentity first = SupabaseLibrarySync.identityFor(server1);
        SupabaseLibrarySync.TitleIdentity second = SupabaseLibrarySync.identityFor(server2);

        assertNotNull(first);
        assertNotNull(second);
        assertTrue(first.id.startsWith("s1-"));
        assertTrue(second.id.startsWith("s2-"));
        assertEquals(67, first.id.length());
        assertEquals(67, second.id.length());
        assertEquals(first.id, SupabaseLibrarySync.identityFor(
                new MainActivity.Item("Renamed", "https://play4u.org/watch/tt123", "", "")).id);
        assertFalse(first.id.equals(second.id));
        assertEquals("https://play4u.org/watch/tt123", SupabaseLibrarySync.catalogUrl("Server 1", "/watch/tt123"));
        assertEquals("https://www.movy.sx/tv/123", SupabaseLibrarySync.catalogUrl("Server 2", "/tv/123"));
    }

    @Test
    public void doesNotSyncPlaybackOrNonCanonicalUrls() {
        assertNull(SupabaseLibrarySync.identityFor(new MainActivity.Item(
                "Stream", "https://play4u.org/path/master.m3u8", "", "")));
        assertNull(SupabaseLibrarySync.identityFor(new MainActivity.Item(
                "Episode", "https://play4u.org/series/tt123/s-02/ep-04", "", "")));
        assertNull(SupabaseLibrarySync.identityFor(new MainActivity.Item(
                "Movie", "https://www.movy.sx/movie/123?season=1", "", "")));
        assertNull(SupabaseLibrarySync.catalogUrl("Server 1", "https://play4u.org/watch/tt123"));
        assertNull(SupabaseLibrarySync.catalogUrl("Server 2", "/embed/123"));
    }

    @Test
    public void titlePayloadDoesNotPersistCredentialedOrStreamPosterUrls() throws Exception {
        MainActivity.Item credentialed = new MainActivity.Item("Example", "/watch/tt123",
                "https://img.example/poster.jpg?token=provider-secret", "2024");
        org.json.JSONObject payload = SupabaseLibrarySync.titlePayload("user-a", credentialed);
        assertNotNull(payload);
        assertTrue(payload.isNull("poster_url"));
        assertFalse(payload.toString().contains("provider-secret"));

        MainActivity.Item stream = new MainActivity.Item("Example", "/watch/tt123",
                "https://cdn.example/master.m3u8", "2024");
        payload = SupabaseLibrarySync.titlePayload("user-a", stream);
        assertNotNull(payload);
        assertTrue(payload.isNull("poster_url"));
        assertFalse(payload.toString().contains("master.m3u8"));
    }

    @Test
    public void parsesPostgresFractionalTimestampsAndOffsets() {
        long utc = SupabaseLibrarySync.parseTimestamp("2026-11-21T22:08:00.123456+00:00");
        long offset = SupabaseLibrarySync.parseTimestamp("2026-11-22T03:38:00.123+05:30");
        assertEquals(utc, offset);
        assertEquals("2026-11-21T22:08:00.123Z", SupabaseLibrarySync.formatTimestamp(utc));
        assertEquals(0L, SupabaseLibrarySync.parseTimestamp("not-a-timestamp"));
    }

    @Test
    public void equalTimestampRemovalWinsButOlderRemovalDoesNot() {
        assertTrue(SupabaseLibrarySync.localWinsForTest(1000L, false, 1000L, true));
        assertFalse(SupabaseLibrarySync.localWinsForTest(999L, false, 1000L, true));
        assertTrue(SupabaseLibrarySync.localWinsForTest(1001L, true, 1000L, false));
        assertFalse(SupabaseLibrarySync.localWinsForTest(1000L, true, 1000L, false));
    }

    @Test
    public void removalTombstoneIsPersistedAndCanBeUndone() throws Exception {
        android.content.Context context = RuntimeEnvironment.getApplication();
        android.content.SharedPreferences prefs = context.getSharedPreferences("vibeflix_supabase_library_sync", android.content.Context.MODE_PRIVATE);
        prefs.edit().clear().commit();
        MainActivity.Item item = new MainActivity.Item("Example", "/watch/tt123", "https://img.example/poster.jpg", "2024");
        SupabaseLibrarySync.TitleIdentity identity = SupabaseLibrarySync.identityFor(item);

        long removedAt = System.currentTimeMillis();
        item.time = removedAt;
        SupabaseLibrarySync.recordMyListTombstone(context, item, removedAt);
        org.json.JSONObject tombstones = new org.json.JSONObject(prefs.getString("my_list_tombstones_v1", "{}"));
        assertEquals(removedAt, tombstones.getJSONObject(identity.id).getLong("time"));
        assertTrue(SupabaseLibrarySync.nextMyListTimestamp(context, item) > removedAt);

        SupabaseLibrarySync.clearMyListTombstone(context, item);
        tombstones = new org.json.JSONObject(prefs.getString("my_list_tombstones_v1", "{}"));
        assertFalse(tombstones.has(identity.id));
    }

    @Test
    public void syncConsentIsBoundToTheAccount() {
        android.content.Context context = RuntimeEnvironment.getApplication();
        android.content.SharedPreferences prefs = context.getSharedPreferences("vibeflix_supabase_library_sync", android.content.Context.MODE_PRIVATE);
        prefs.edit().clear().commit();
        prefs.edit().putString("my_list_sync_user_id", "user-a").commit();
        assertFalse(SupabaseLibrarySync.isEnabledFor(context, "user-a"));
        SupabaseLibrarySync.enableFor(context, "user-a");
        assertTrue(SupabaseLibrarySync.isEnabledFor(context, "user-a"));
        assertFalse(SupabaseLibrarySync.isEnabledFor(context, "user-b"));
    }
}
