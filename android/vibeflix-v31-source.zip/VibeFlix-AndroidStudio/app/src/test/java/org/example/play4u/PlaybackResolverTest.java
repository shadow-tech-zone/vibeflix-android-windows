package org.example.play4u;
import org.junit.Test;import org.junit.runner.RunWith;import org.robolectric.RobolectricTestRunner;import org.robolectric.annotation.Config;import java.nio.charset.StandardCharsets;import android.util.Base64;import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class PlaybackResolverTest {
 @Test public void decodedStreamIsHttps() throws Exception {String url="https://example.org/master.jpg",key="sample-key";byte[] x=url.getBytes(StandardCharsets.UTF_8), k=key.getBytes(StandardCharsets.UTF_8);for(int i=0;i<x.length;i++)x[i]^=k[i%k.length];String token=Base64.encodeToString(x,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING);String html="<script>window.__PA_SEAL_KEY__ = \"sample-key\";window.__PA_PLAY__ = {\"streams\":[{\"m3u8_url\":\"pa!~"+token+"\"}]};</script>";assertEquals(url,PlaybackResolver.resolve(html));}
 @Test public void relativeStreamIsResolved() throws Exception {assertEquals("https://play4u.org/path/master.m3u8",PlaybackResolver.resolve("window.__PA_PLAY__ = {\"streams\":[{\"m3u8_url\":\"/path/master.m3u8\"}]};"));}
 @Test(expected=IllegalStateException.class) public void rejectsMissingStreams() throws Exception {PlaybackResolver.resolve("window.__PA_PLAY__ = {\"streams\":[]};");}
 @Test(expected=IllegalStateException.class) public void rejectsInsecureStream() throws Exception {PlaybackResolver.resolve("window.__PA_PLAY__ = {\"streams\":[{\"m3u8_url\":\"http://example.org/stream.m3u8\"}]};");}
}
