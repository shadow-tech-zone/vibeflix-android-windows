package org.example.play4u;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class SupabaseAuthClientTest {
    @Test
    public void signInRequiresHttpsAndPublishableKey() throws Exception {
        assertFalse(new SupabaseAuthClient("https://project.supabase.co", "").isConfigured());
        assertFalse(new SupabaseAuthClient("http://project.supabase.co", "sb_publishable_test").isConfigured());
        assertTrue(new SupabaseAuthClient("https://project.supabase.co/", "sb_publishable_test").isConfigured());
    }

    @Test
    public void rejectsSecretStyleAndLegacyServiceRoleKeys() {
        assertFalse(new SupabaseAuthClient("https://project.supabase.co", "sb_secret_do_not_use").isConfigured());
        assertFalse(new SupabaseAuthClient("https://project.supabase.co", legacyJwt("service_role")).isConfigured());
        assertTrue(new SupabaseAuthClient("https://project.supabase.co", legacyJwt("anon")).isConfigured());
    }

    @Test
    public void unconfiguredSignInDoesNotAttemptNetworkRequest() throws Exception {
        SupabaseAuthClient client = new SupabaseAuthClient("https://project.supabase.co", "");
        try {
            client.signIn("owner@example.invalid", "not-a-real-password");
            fail("Expected cloud auth to remain disabled without a build-time publishable key");
        } catch (SupabaseAuthClient.AuthException expected) {
            assertEquals(0, expected.statusCode);
            assertTrue(expected.getMessage().contains("not configured"));
        }
    }

    private static String legacyJwt(String role) {
        String payload = "{\"role\":\"" + role + "\"}";
        String encoded = Base64.getUrlEncoder().withoutPadding()
                .encodeToString(payload.getBytes(StandardCharsets.UTF_8));
        return "header." + encoded + ".signature";
    }
}
