# Episode flow restoration (review v30)

Base: pre-TMDB v18 restored build. The native player episode/next/resume fixes from the later review build were selectively brought back along with title-owned resume validation, while the Server 2 API adapter and catalog remain unchanged from restored v18. The earlier v18 Episodes button/list are retained. No direct TMDB experiment was integrated. Movie orientation remains as v18.

Episode button and immediate opening of the episode sheet have Robolectric UI coverage; results require provider episode metadata. Next episode lookup for both sources and 40-second threshold have unit tests, including seek-back and generic-series redirects. Resume validates the title/episode and avoids writing progress until at least five seconds of observed playback; ambiguous older generic-series positions are ignored. Unknown stream duration may prevent a 40-second prompt, and no next button is possible without next-episode metadata. Already-corrupted positions for the same episode cannot be recognized reliably.

63 automated tests passed in sequential batches. Server 2 HTTP 429/403 was seen from the sandbox in earlier live checks; neither real playback nor a phone UI was verified. Release lint skipped because offline lint dependencies were unavailable. Play Protect warning unresolved; do not bypass it.
