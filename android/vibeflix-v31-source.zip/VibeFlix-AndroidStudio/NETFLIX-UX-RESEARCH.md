# Vibeflix mobile UX review

References reviewed 2026-11-16 (Netflix is not affiliated with Vibeflix):
- Netflix Help, mobile navigation: https://help.netflix.com/en/node/575087423404644 — bottom destinations; content-type and category filters at top. Netflix has Clips, but Vibeflix does not have a trustworthy short-form catalog, so no fake Clips tab was added.
- Netflix 2026 mobile announcement and official Home screenshot: https://about.netflix.com/en/news/introducing-exciting-new-ways-to-find-and-enjoy-your-next-favorite-on-mobile — visual hierarchy: Home, quick filters, featured title with Play/My List, horizontal content rails.
- Netflix My Netflix: https://about.netflix.com/en/news/introducing-my-netflix-a-one-stop-shop-for-series-and-movies-you-want-to — keep saved and started titles accessible from one destination; Vibeflix is local-only, not synced profiles/downloads.
- Netflix Help: https://help.netflix.com/en/node/115312 — Continue Watching has an explicit Remove from Row menu on mobile. Hiding a row item must not erase its saved playback position.
- Netflix accessibility release notes: https://help.netflix.com/en/node/119359 — labeled controls, larger targets, headings, contrast, long labels and user-set accessibility timeouts.
- Netflix Android episode selection: https://techwiser.com/how-to-change-seasons-or-episodes-on-netflix/ — current-season episodes appear first; season picker changes the list within the flow.
- Netflix player redesign: https://www.androidpolice.com/2018/05/29/netflix-finally-redesigns-player-ui-larger-controls-next-episode-button/ — centered primary controls, labeled episode and settings actions at the bottom. Older design reference, not a claim of current pixel parity.

No proprietary Netflix assets or Netflix Sans used. No Clips, autoplay recommendations, notification, sync, downloads or sharing are fabricated. Play4u/Movy are independent sources; Movy stream access can fail. Android Play Protect warning remains unresolved.

The implementation is an incremental native UX refinement, not a claim of Netflix parity. It requires real-device, accessibility, orientation and provider compatibility testing.
