# VibeFlix Android project

Open this folder in Android Studio with JDK 17 and Android SDK Platform 34. Gradle wrapper 7.6.4 / Android Gradle Plugin 7.4.2 is included. Run `./gradlew :app:assembleDebug` or `./gradlew :app:testDebugUnitTest`.

## Playback architecture
Version 4.0 uses AndroidX Media3 ExoPlayer + HLS and PlayerView instead of the website's WebView player. A resolver fetches the website's public player bootstrap data and resolves its current encoded stream URL. The website can change this format or reject playback. This is not a DRM bypass: DRM streams and protected content are not handled.

Native player supports play/pause, seek, rotation, Media3 track UI (dependent on stream/device), and locally stored playback position. History and My List are also local. No offline downloading or cross-device sync.

The Android app's search directly implements the public search request discovered through API Anything; a local-only learned specification is included. Catalog and detail data are still based on website HTML.

## Verification and limitations
Gradle build passed and the JVM/Robolectric resolver, navigation and local storage tests passed. Two live public titles were checked through HLS master, variant, and initial segment HTTP requests. A later attempt at a Robolectric NativePlayerActivity test did not finish in the constrained environment and was removed; playback and rendering were not tested on an Android device. An emulator could not boot without hardware acceleration and sufficient memory. Test playback, audio/subtitle selection, rotation and black-screen behavior on a real phone before considering it fixed.

## Signing
The accompanying APK is signed with the same key as earlier versions and can be installed as an update. The signing key is not included. Android Studio will use its own debug key by default, so APKs you build locally cannot update the installed version without the original key. Uninstalling the old app deletes local history/list data.
