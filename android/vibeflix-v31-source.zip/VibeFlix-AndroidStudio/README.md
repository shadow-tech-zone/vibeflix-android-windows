# VibeFlix Android project

Open this folder in Android Studio with JDK 17 and Android SDK Platform 34. Gradle wrapper 7.6.4 / Android Gradle Plugin 7.4.2 is included. Run `./gradlew :app:assembleDebug` or `./gradlew :app:testDebugUnitTest`.

## Playback architecture
Version 4.0 uses AndroidX Media3 ExoPlayer + HLS and PlayerView instead of the website's WebView player. A resolver fetches the website's public player bootstrap data and resolves its current encoded stream URL. The website can change this format or reject playback. This is not a DRM bypass: DRM streams and protected content are not handled.

Native player supports play/pause, seek, rotation, Media3 track UI (dependent on stream/device), and locally stored playback position. My List, watch History, Continue Watching visibility, and resume remain local by default. Cross-device library sync is optional and requires explicit per-account consent; sync failures never erase local data. Cloud payloads use canonical catalog metadata and validated episode keys only—never stream/playback URLs or provider credentials. No offline downloading is provided.

The Android app's search directly implements the public search request discovered through API Anything; a local-only learned specification is included. Catalog and detail data are still based on website HTML.

## Verification and limitations
The imported baseline previously passed its Gradle build and JVM/Robolectric resolver, navigation, and local-storage tests. The added Supabase library-sync code and tests require a fresh CI run. Two live public titles were previously checked through HLS master, variant, and initial segment HTTP requests. A later attempt at a Robolectric NativePlayerActivity test did not finish in the constrained environment and was removed; playback and rendering were not tested on an Android device. An emulator could not boot without hardware acceleration and sufficient memory. Test playback, audio/subtitle selection, rotation and black-screen behavior on a real phone before considering it fixed.

## Signing
No release signing key or password is included. Previously exposed legacy signing material must not be reused; a replacement key, approved rotation lineage, and protected CI secrets are required before publishing an update. Local debug builds use a separate debug key and cannot update packages signed by another key. Keep local data backed up before uninstalling an installed build.
